function (profile, previouslySubmitted) {
    'use strict';
    const result = (status, submitted) => ({status, submitted: Array.from(submitted || [])});
    if (window.top !== window || location.protocol !== 'https:' || location.hostname !== 'signup.live.com')
        return result('blocked-origin', previouslySubmitted);
    const receiptKey = 'rl-signup-receipt-' + profile.runId;
    if (!/^[A-Za-z0-9-]{8,64}$/.test(profile.runId || '')) return result('invalid-session', previouslySubmitted);
    let persisted;
    try { persisted = JSON.parse(sessionStorage.getItem(receiptKey) || '[]'); }
    catch (_) { return result('storage-error', previouslySubmitted); }
    const submitted = new Set([...(previouslySubmitted || []), ...(Array.isArray(persisted) ? persisted : [])]);
    const visible = el => el && !el.disabled && el.getClientRects().length > 0 &&
        getComputedStyle(el).visibility !== 'hidden';
    const find = selector => Array.from(document.querySelectorAll(selector)).find(visible);
    const pageText = document.body.innerText || '';
    // Never inspect a challenge frame or verification-code value.
    if (Array.from(document.querySelectorAll('iframe')).some(el => visible(el) &&
        /captcha|arkoselabs|funcaptcha|hcaptcha|recaptcha/i.test((el.src || '') + ' ' + (el.title || ''))) ||
        /prove (?:that )?you(?:['’]re| are) human|verify (?:that )?you(?:['’]re| are) human|help us beat.*robots|press and hold|أثبت أنك|لست روبوت|حل اللغز|اضغط مع الاستمرار|التحقق من أنك إنسان/i.test(pageText))
        return result('captcha', submitted);
    if (find('input[autocomplete="one-time-code"], input[name="otc"], input[name="code"], input[name="VerificationCode"], input[name="VerificationCodeInput"], input#VerificationCode') ||
        /enter (the )?(verification |security )?code|check your email|أدخل رمز|أدخل الرمز|كود التحقق|رمز التحقق/i.test(pageText))
        return result('verification', submitted);
    // Microsoft errors require user review, never automated retry/resend.
    if (find('[role="alert"], .field-validation-error, #MemberNameError, #PasswordError'))
        return result('review-error', submitted);
    const email = find('input[name="email"][type="email"], input[name="MemberName"], input#MemberName');
    const pass = find('input[type="password"][autocomplete="new-password"], input[type="password"][name="Password"], input[type="password"][name="password"], input#PasswordInput');
    const first = find('input[autocomplete="given-name"], input[name="FirstName"], input[name="firstName"], input#FirstName');
    const last = find('input[autocomplete="family-name"], input[name="LastName"], input[name="lastName"], input#LastName');
    const day = find('[name="BirthDay"], #BirthDay, input[autocomplete="bday-day"], select[autocomplete="bday-day"]');
    const month = find('[name="BirthMonth"], #BirthMonth, input[autocomplete="bday-month"], select[autocomplete="bday-month"]');
    const year = find('[name="BirthYear"], #BirthYear, input[autocomplete="bday-year"], select[autocomplete="bday-year"]');
    const country = find('select[name="Country"], select#Country, select[name="CountryCode"], select[autocomplete="country"]');
    const stage = email ? 'email' : pass ? 'password' : (first || last) ? 'name' : (day || month || year || country) ? 'birth' : null;
    if (!stage) return result('manual-step', submitted);
    if (submitted.has(stage)) return result('awaiting-next-page', submitted);
    function fill(el, value) {
        if (!el || el.readOnly || typeof value !== 'string' || !value) return false;
        if (el instanceof HTMLSelectElement) {
            const option = Array.from(el.options).find(o => !o.disabled &&
                (o.value.toUpperCase() === value.toUpperCase() || (/^\d+$/.test(value) && /^\d+$/.test(o.value) && Number(o.value) === Number(value))));
            if (!option) return false;
            if (el.value !== option.value) {
                Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, 'value').set.call(el, option.value);
                el.dispatchEvent(new Event('input', {bubbles:true}));
                el.dispatchEvent(new Event('change', {bubbles:true}));
            }
            return true;
        }
        if (!(el instanceof HTMLInputElement) || !['text','email','password','number','tel'].includes(el.type)) return false;
        // Preserve edits; a mismatch asks for review instead of silently sending another account/password.
        if (el.value && el.value !== value) return false;
        if (!el.value) {
            Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(el, value);
            el.dispatchEvent(new Event('input', {bubbles:true}));
            el.dispatchEvent(new Event('change', {bubbles:true}));
        }
        return el.value === value;
    }
    let fields;
    if (stage === 'email') fields = [[email, profile.email]];
    else if (stage === 'password') fields = [[pass, profile.password]];
    else if (stage === 'name') fields = [[first, profile.firstName],[last, profile.lastName]];
    else fields = [[day, profile.day],[month, profile.month],[year, profile.year], ...(country ? [[country, profile.country]] : [])];
    if (!fields.every(([el,value]) => fill(el,value))) return result('review-fields', submitted);
    // Do not submit a form with any other visible data input or required consent unchecked.
    const known = fields.map(([el]) => el);
    const unhandled = Array.from(document.querySelectorAll('input,select,textarea')).some(el => {
        if (!visible(el) || el.readOnly || known.includes(el)) return false;
        if (el.type === 'checkbox' || el.type === 'radio') return el.required && !el.checked;
        return !['hidden','button','submit','reset'].includes(el.type);
    });
    if (unhandled) return result('review-fields', submitted);
    if (fields.some(([el]) => el.validity && !el.validity.valid)) return result('review-fields', submitted);
    const buttons = Array.from(document.querySelectorAll('button,input[type="submit"]')).filter(visible);
    const next = buttons.filter(el => /^(next|continue|التالي|التالى|متابعة)$/i.test((el.innerText || el.value || '').trim()));
    if (next.length !== 1) return result('manual-step', submitted);
    if (next[0].getAttribute('aria-disabled') === 'true') return result('waiting-button', submitted);
    // Give reactive forms a full tick to accept state; require the same recognized stage twice.
    const lastReady = window.__rlSignupReady;
    if (!lastReady || lastReady.stage !== stage || Date.now()-lastReady.at < 900) {
        if (!lastReady || lastReady.stage !== stage) window.__rlSignupReady={stage,at:Date.now()};
        return result('filled-'+stage, submitted);
    }
    submitted.add(stage); // Persist receipt before click, including across same-origin reloads.
    try { sessionStorage.setItem(receiptKey, JSON.stringify(Array.from(submitted))); }
    catch (_) { submitted.delete(stage); return result('storage-error', submitted); }
    next[0].click();
    return result('submitted-'+stage, submitted);
}
