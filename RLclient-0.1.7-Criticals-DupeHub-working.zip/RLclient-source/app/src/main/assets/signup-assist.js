function (profile) {
    'use strict';
    if (window.top !== window || location.protocol !== 'https:' || location.hostname !== 'signup.live.com') {
        return 'blocked-origin';
    }
    if (window.__rlSignupAssistStop) window.__rlSignupAssistStop();
    const specs = [
        ['email', 'input[name="email"][type="email"], input[name="MemberName"], input#MemberName'],
        ['firstName', 'input[autocomplete="given-name"], input[name="FirstName"], input[name="firstName"], input#FirstName'],
        ['lastName', 'input[autocomplete="family-name"], input[name="LastName"], input[name="lastName"], input#LastName']
    ];
    const completed = new Set();
    let count = 0;
    function fill() {
        for (const [key, selector] of specs) {
            const value = profile[key];
            if (completed.has(key) || typeof value !== 'string' || !value.trim()) continue;
            const field = Array.from(document.querySelectorAll(selector)).find(el =>
                !el.disabled && !el.readOnly && ['email', 'text'].includes(el.type) &&
                el.getClientRects().length > 0 && getComputedStyle(el).visibility !== 'hidden');
            if (!field) continue;
            // Never overwrite a value entered by the user or their browser.
            completed.add(key);
            if (field.value) continue;
            const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
            setter.call(field, value.trim());
            field.dispatchEvent(new Event('input', {bubbles: true}));
            field.dispatchEvent(new Event('change', {bubbles: true}));
            count++;
        }
    }
    fill();
    const observer = new MutationObserver(fill);
    observer.observe(document.documentElement, {childList: true, subtree: true});
    const timeout = setTimeout(() => observer.disconnect(), 20000);
    window.__rlSignupAssistStop = () => { observer.disconnect(); clearTimeout(timeout); };
    return count > 0 ? 'filled' : 'waiting-for-fields';
}
