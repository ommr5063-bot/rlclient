package com.retrivedmods.wclient.network;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

/** SOCKS5 UDP ASSOCIATE. Connection failures never fall back to a direct route. */
public final class Socks5UdpTunnel implements AutoCloseable {
    private Socket control;
    private DatagramSocket local, upstream;
    private volatile boolean running;
    private volatile SocketAddress client;
    private byte[] header;
    public synchronized InetSocketAddress start(String proxyHost, int proxyPort, String username,
            String password, String targetHost, int targetPort) throws IOException {
        if (running) throw new IOException("Proxy tunnel is already running");
        if (proxyPort < 1 || proxyPort > 65535 || targetPort < 1 || targetPort > 65535) throw new IOException("Invalid port");
        try {
            control = new Socket();
            control.connect(new InetSocketAddress(proxyHost, proxyPort), 12000);
            control.setSoTimeout(12000);
            DataInputStream input = new DataInputStream(control.getInputStream());
            OutputStream output = control.getOutputStream();
            boolean auth = !username.isEmpty();
            output.write(new byte[]{5, 1, (byte)(auth ? 2 : 0)}); output.flush();
            int version = input.readUnsignedByte(), method = input.readUnsignedByte();
            if (version != 5 || method != (auth ? 2 : 0)) throw new IOException("Proxy authentication method rejected");
            if (auth) {
                byte[] user = username.getBytes(StandardCharsets.UTF_8), pass = password.getBytes(StandardCharsets.UTF_8);
                if (user.length > 255 || pass.length > 255) throw new IOException("Proxy credentials are too long");
                output.write(1); output.write(user.length); output.write(user); output.write(pass.length); output.write(pass); output.flush();
                if (input.readUnsignedByte() != 1 || input.readUnsignedByte() != 0) throw new IOException("Proxy authentication failed");
            }
            output.write(new byte[]{5, 3, 0, 1, 0, 0, 0, 0, 0, 0}); output.flush();
            int replyVersion = input.readUnsignedByte(), result = input.readUnsignedByte(), reserved = input.readUnsignedByte();
            if (replyVersion != 5 || result != 0 || reserved != 0) throw new IOException("SOCKS5 UDP ASSOCIATE rejected: " + result);
            InetAddress relay = readAddress(input);
            int port = input.readUnsignedShort();
            if (port == 0) throw new IOException("Invalid UDP relay port");
            if (relay.isAnyLocalAddress()) relay = control.getInetAddress();
            byte[] host = IDN.toASCII(targetHost).getBytes(StandardCharsets.US_ASCII);
            if (host.length == 0 || host.length > 255) throw new IOException("Invalid server address");
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            DataOutputStream data = new DataOutputStream(bytes);
            data.writeShort(0); data.writeByte(0); data.writeByte(3); data.writeByte(host.length); data.write(host); data.writeShort(targetPort);
            header = bytes.toByteArray();
            local = new DatagramSocket(new InetSocketAddress(InetAddress.getByName("127.0.0.1"), 0));
            upstream = new DatagramSocket(); upstream.connect(new InetSocketAddress(relay, port));
            control.setSoTimeout(0); running = true;
            worker("SOCKS5-outbound", this::sendLoop);
            worker("SOCKS5-inbound", this::receiveLoop);
            worker("SOCKS5-control", () -> { while (running && input.read() != -1) { } });
            return new InetSocketAddress("127.0.0.1", local.getLocalPort());
        } catch (Exception error) {
            close();
            if (error instanceof IOException) throw (IOException)error;
            throw new IOException("Cannot start proxy tunnel", error);
        }
    }
    private interface IoTask { void run() throws IOException; }
    private void worker(String name, IoTask task) {
        Thread thread = new Thread(() -> { try { task.run(); } catch (IOException ignored) { } finally { close(); } }, name);
        thread.setDaemon(true); thread.start();
    }
    private void sendLoop() throws IOException {
        byte[] buffer = new byte[65507];
        while (running) {
            DatagramPacket packet = new DatagramPacket(buffer, buffer.length); local.receive(packet);
            if (!packet.getAddress().isLoopbackAddress()) continue;
            client = packet.getSocketAddress();
            int size = packet.getLength();
            if (header.length + size > 65507) continue;
            byte[] framed = Arrays.copyOf(header, header.length + size);
            System.arraycopy(packet.getData(), packet.getOffset(), framed, header.length, size);
            upstream.send(new DatagramPacket(framed, framed.length));
        }
    }
    private void receiveLoop() throws IOException {
        byte[] buffer = new byte[65507];
        while (running) {
            DatagramPacket packet = new DatagramPacket(buffer, buffer.length); upstream.receive(packet);
            int size = packet.getLength();
            if (size < 7 || buffer[0] != 0 || buffer[1] != 0 || buffer[2] != 0) continue;
            int type = buffer[3] & 255;
            int offset;
            if (type == 1) offset = 10;
            else if (type == 4) offset = 22;
            else if (type == 3) offset = 7 + (buffer[4] & 255);
            else continue;
            SocketAddress destination = client;
            if (destination != null && size >= offset) local.send(new DatagramPacket(buffer, offset, size - offset, destination));
        }
    }
    private static InetAddress readAddress(DataInputStream input) throws IOException {
        int type = input.readUnsignedByte();
        if (type == 1 || type == 4) {
            byte[] address = new byte[type == 1 ? 4 : 16]; input.readFully(address); return InetAddress.getByAddress(address);
        }
        if (type == 3) {
            byte[] name = new byte[input.readUnsignedByte()]; input.readFully(name);
            return InetAddress.getByName(new String(name, StandardCharsets.US_ASCII));
        }
        throw new IOException("Invalid SOCKS5 address type");
    }
    @Override public synchronized void close() {
        running = false;
        if (local != null) local.close();
        if (upstream != null) upstream.close();
        if (control != null) try { control.close(); } catch (IOException ignored) { }
        client = null;
    }
}
