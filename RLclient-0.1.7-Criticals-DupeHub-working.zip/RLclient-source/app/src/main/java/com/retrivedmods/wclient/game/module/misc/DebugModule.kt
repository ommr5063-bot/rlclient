package com.retrivedmods.wclient.game.module.misc

import com.retrivedmods.wclient.game.InterceptablePacket
import com.retrivedmods.wclient.game.Module
import com.retrivedmods.wclient.game.ModuleCategory
import com.retrivedmods.wclient.game.entity.Entity
import com.retrivedmods.wclient.game.entity.EntityUnknown
import com.retrivedmods.wclient.game.entity.LocalPlayer
import com.retrivedmods.wclient.game.entity.Player
import org.cloudburstmc.protocol.bedrock.packet.BedrockPacket
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/** Packet and nearby-entity diagnostics. No latency is inferred from packet timing. */
class DebugModule : Module("Debug", ModuleCategory.Misc) {

    private val logPackets by boolValue("Log Packets", true)
    private val targetInfo by boolValue("Target Info", true)
    private val targetRange by floatValue("Target Range", 6.0f, 1.0f..32.0f)
    private val updateInterval by intValue("Update Interval (ms)", 2000, 500..10000)

    private val packetCounts = ConcurrentHashMap<String, Int>()
    private var lastPacketReportAt = 0L
    private var lastInfoUpdateAt = 0L
    private var lastTargetMessage: String? = null

    override fun beforePacketBound(interceptablePacket: InterceptablePacket) {
        if (!isEnabled || !isSessionCreated) return

        val now = System.currentTimeMillis()
        if (logPackets) countPacket(interceptablePacket.packet)

        if (now - lastInfoUpdateAt >= updateInterval.toLong()) {
            lastInfoUpdateAt = now
            displayInfo()
        }

        if (logPackets && now - lastPacketReportAt >= PACKET_REPORT_INTERVAL_MS) {
            lastPacketReportAt = now
            reportPacketCounts()
        }
    }


    private fun countPacket(packet: BedrockPacket) {
        packetCounts.merge(packet.javaClass.simpleName, 1) { old, increment -> old + increment }
    }

    private fun displayInfo() {
        if (!isSessionCreated) return

        val entities = session.level.entityMap.values
        val playerCount = entities.count { it is Player && it !is LocalPlayer }
        val entityCount = entities.count { it !is LocalPlayer }
        session.displayClientMessage("§7[Debug] Players: §a$playerCount §7| Entities: §b$entityCount")

        if (targetInfo) {
            val targetMessage = findNearestEntity()?.let { (entity, distance) ->
                val name = getEntityName(entity)
                "§7[Debug] Target: §e$name §7| Dist: §b${String.format(Locale.ROOT, "%.2f", distance)}m"
            } ?: "§7[Debug] Target: §8None"

            if (targetMessage != lastTargetMessage) {
                session.displayClientMessage(targetMessage)
                lastTargetMessage = targetMessage
            }
        }
    }

    /** Proximity-based lookup, not a line-of-sight or ray-traced target. */
    private fun findNearestEntity(): Pair<Entity, Float>? {
        val player = session.localPlayer
        return session.level.entityMap.values.asSequence()
            .filter { it !is LocalPlayer }
            .map { entity -> entity to entity.distance(player) }
            .filter { (entity, distance) ->
                distance.isFinite() && distance <= targetRange &&
                    (entity is Player || entity is EntityUnknown)
            }
            .minByOrNull { it.second }
    }

    private fun getEntityName(entity: Entity): String = when (entity) {
        is Player -> session.level.playerMap[entity.uuid]?.name?.toString()
            ?.takeIf { it.isNotBlank() } ?: "Player"
        is EntityUnknown -> entity.identifier.substringAfter(':').ifBlank { "Unknown" }
        else -> entity.javaClass.simpleName
    }

    private fun reportPacketCounts() {
        if (packetCounts.isEmpty() || !isSessionCreated) return

        val summary = packetCounts.entries
            .sortedByDescending { it.value }
            .take(MAX_PACKET_TYPES_PER_REPORT)
            .joinToString(" §8| ") { (packetName, count) ->
                "§f$packetName §7x§a$count"
            }

        packetCounts.clear()
        session.displayClientMessage("§l§c[Debug Packets]§r $summary")
    }

    override fun onDisabled() {
        resetDiagnostics()
        super.onDisabled()
    }

    override fun onDisconnect(reason: String) {
        resetDiagnostics()
    }

    private fun resetDiagnostics() {
        packetCounts.clear()
        lastPacketReportAt = 0L
        lastInfoUpdateAt = 0L
        lastTargetMessage = null
    }

    private companion object {
        const val PACKET_REPORT_INTERVAL_MS = 5000L
        const val MAX_PACKET_TYPES_PER_REPORT = 8
    }
}
