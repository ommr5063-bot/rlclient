package com.retrivedmods.wclient.game.module.combat

import com.retrivedmods.wclient.game.InterceptablePacket
import com.retrivedmods.wclient.game.Module
import com.retrivedmods.wclient.game.ModuleCategory
import org.cloudburstmc.protocol.bedrock.data.PlayerAuthInputData
import org.cloudburstmc.protocol.bedrock.data.inventory.transaction.InventoryTransactionType
import org.cloudburstmc.protocol.bedrock.packet.InventoryTransactionPacket
import org.cloudburstmc.protocol.bedrock.packet.MovePlayerPacket
import org.cloudburstmc.protocol.bedrock.packet.PlayerAuthInputPacket
import org.cloudburstmc.math.vector.Vector3f
import java.util.ArrayDeque

/**
 * Delays entity attacks until the local player is actually descending.
 * Jump mode requests a normal Bedrock jump through the next grounded
 * PlayerAuthInputPacket; it does not spoof arbitrary Y coordinates.
 * The server still decides whether the resulting hit is critical.
 */
class CriticalsModule : Module("criticals", ModuleCategory.Combat) {

    private enum class Mode { Packet, Jump, MiniJump }

    private val mode by enumValue("Mode", Mode.Jump, Mode::class.java)

    private val stateLock = Any()
    private val pendingAttacks = ArrayDeque<InventoryTransactionPacket>()

    private var jumpRequested = false
    private var pendingSinceMs = 0L
    private var lastMovementWasFalling = false
    private var lastMovementPosition: Vector3f? = null

    private val maxPendingAttacks = 4
    private val attackTimeoutMs = 1200L

    override fun onEnabled() {
        clearState()
        super.onEnabled()
    }

    override fun onDisabled() {
        clearState()
        super.onDisabled()
    }

    override fun onDisconnect() {
        clearState()
    }

    private fun clearState() = synchronized(stateLock) {
        pendingAttacks.clear()
        jumpRequested = false
        pendingSinceMs = 0L
        lastMovementWasFalling = false
        lastMovementPosition = null
    }

    override fun beforePacketBound(interceptablePacket: InterceptablePacket) {
        if (!isEnabled || !isSessionCreated) return

        when (val packet = interceptablePacket.packet) {
            is InventoryTransactionPacket -> handleAttack(packet, interceptablePacket)

            is PlayerAuthInputPacket -> handleAuthInput(packet)

            is MovePlayerPacket -> {
                if (packet.runtimeEntityId == session.localPlayer.runtimeEntityId) {
                    synchronized(stateLock) {
                        // This is a server movement update, so the server has
                        // already processed this position before we release hits.
                        if (pendingAttacks.isNotEmpty() && isFalling(session.localPlayer.motionY)) {
                            flushPendingAttacks(session.localPlayer.vec3Position)
                        }
                    }
                }
            }
        }
    }

    private fun handleAttack(
        packet: InventoryTransactionPacket,
        interceptablePacket: InterceptablePacket
    ) {
        if (packet.transactionType != InventoryTransactionType.ITEM_USE_ON_ENTITY || packet.actionType != 1) return

        synchronized(stateLock) {
            val player = session.localPlayer
            if (isFalling(player.motionY)) return

            // Preserve the attack and release it on the first confirmed falling movement.
            if (pendingAttacks.size >= maxPendingAttacks) {
                // Flush in order and intercept the current packet so it is not sent twice.
                flushPendingAttacks(player.vec3Position)
                session.serverBound(packet)
                interceptablePacket.intercept()
                return
            }

            pendingAttacks.addLast(packet)
            if (pendingSinceMs == 0L) pendingSinceMs = System.currentTimeMillis()
            interceptablePacket.intercept()

            if (mode != Mode.Packet) {
                jumpRequested = true
            }
        }
    }

    private fun handleAuthInput(packet: PlayerAuthInputPacket) {
        synchronized(stateLock) {
            val now = System.currentTimeMillis()

            // The previous movement packet has already been forwarded to the server.
            if (pendingAttacks.isNotEmpty() && lastMovementWasFalling) {
                flushPendingAttacks(lastMovementPosition ?: session.localPlayer.vec3Position)
            }

            // Ask the Bedrock server to perform a normal jump only when the
            // movement packet reports a vertical collision (grounded/landing).
            if (jumpRequested &&
                packet.inputData.contains(PlayerAuthInputData.VERTICAL_COLLISION) &&
                session.localPlayer.motionY <= 0.01f
            ) {
                packet.inputData.add(PlayerAuthInputData.JUMP_DOWN)
                packet.inputData.add(PlayerAuthInputData.START_JUMPING)
                packet.inputData.add(PlayerAuthInputData.JUMPING)
                jumpRequested = false
            }

            lastMovementWasFalling = isFalling(session.localPlayer.motionY)
            lastMovementPosition = packet.position

            // Safety fallback: never hold a user's attack indefinitely if the
            // server does not acknowledge the jump/fall sequence.
            if (pendingAttacks.isNotEmpty() && pendingSinceMs != 0L && now - pendingSinceMs >= attackTimeoutMs) {
                flushPendingAttacks(packet.position)
            }
        }
    }

    private fun isFalling(verticalDelta: Float): Boolean {
        // MiniJump releases on the first detectable downward movement;
        // the server still controls the actual jump height.
        val threshold = when (mode) {
            Mode.MiniJump -> -0.015f
            Mode.Jump -> -0.06f
            else -> -0.03f
        }
        return verticalDelta < threshold
    }

    private fun flushPendingAttacks(position: Vector3f) {
        while (pendingAttacks.isNotEmpty()) {
            val attack = pendingAttacks.removeFirst()
            attack.playerPosition = position
            session.serverBound(attack)
        }
        pendingSinceMs = 0L
        jumpRequested = false
    }
}
