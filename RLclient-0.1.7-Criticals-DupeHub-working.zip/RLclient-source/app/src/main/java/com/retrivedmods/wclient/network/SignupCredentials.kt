package com.retrivedmods.wclient.network

import android.content.Context
import java.security.MessageDigest
import java.security.SecureRandom
import java.time.LocalDate
import java.util.Locale
import org.json.JSONObject

data class SignupProfile(
    val email: String, val firstName: String, val lastName: String,
    val day: String, val month: String, val year: String, val country: String,
    val password: String
) {
    fun json(): String = JSONObject().put("email", email).put("firstName", firstName)
        .put("lastName", lastName).put("day", day).put("month", month).put("year", year)
        .put("country", country).put("password", password).toString()
}

object SignupCredentials {
    private fun key(email: String): String = "signup_" + MessageDigest.getInstance("SHA-256")
        .digest(email.trim().lowercase(Locale.ROOT).toByteArray(Charsets.UTF_8))
        .joinToString("") { "%02x".format(it) }
    fun load(context: Context, email: String): String = SecretStorage.load(context, key(email))
    fun getOrCreate(context: Context, email: String): String {
        val existing = load(context, email)
        if (existing.isNotEmpty()) return existing
        val random = SecureRandom()
        val alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#%+-_"
        val chars = ("Rr7!" + (1..20).map { alphabet[random.nextInt(alphabet.length)] }.joinToString("")).toCharArray()
        for (i in chars.lastIndex downTo 1) {
            val j = random.nextInt(i+1); val tmp=chars[i]; chars[i]=chars[j]; chars[j]=tmp
        }
        return String(chars).also { SecretStorage.save(context, key(email), it) }
    }
    fun validateDate(day: String, month: String, year: String) {
        val date = try { LocalDate.of(year.toInt(), month.toInt(), day.toInt()) }
            catch (_: Exception) { throw IllegalArgumentException("أدخل يوم وشهر وسنة ميلاد صحيحة.") }
        require(!date.isAfter(LocalDate.now()) && date.year >= 1900) { "تحقق من تاريخ الميلاد." }
    }
}
