package com.retrivedmods.wclient.game

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.retrivedmods.wclient.game.entity.Player
import com.retrivedmods.wclient.game.module.combat.TargetPlayerModule
import kotlinx.coroutines.delay

@Composable
fun TargetPlayerControls(module: TargetPlayerModule) {
    var players by remember { mutableStateOf<List<Player>>(emptyList()) }
    var selected by remember { mutableStateOf<TargetPlayerModule.Selection?>(null) }
    LaunchedEffect(module, module.isEnabled) {
        while (module.isEnabled) { players = module.nearbyPlayers(); selected = module.selection; delay(400) }
        players = emptyList(); selected = null
    }
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
        Text("اللاعبون القريبون")
        if (!module.isEnabled) Text("فعّل Target Player لعرض اللاعبين.")
        else if (!module.isSessionCreated) Text("بانتظار الاتصال بالعالم…")
        else if (players.isEmpty()) Text("لا يوجد لاعبون ضمن المسافة المحددة.")
        players.forEach { player ->
            OutlinedButton(onClick = { module.select(player); selected = module.selection }, modifier = Modifier.fillMaxWidth()) {
                val marker = if (selected?.id == player.runtimeEntityId) "✓ " else ""
                Text("$marker${player.username} • ${"%.1f".format(player.distance(module.session.localPlayer))} بلوكة")
            }
        }
        if (selected != null) TextButton(onClick = { module.select(null); selected = null }) { Text("إلغاء اختيار اللاعب") }
    }
}
