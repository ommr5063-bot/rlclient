package com.retrivedmods.wclient.router.main

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Patterns
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.retrivedmods.wclient.network.SecretStorage
import com.retrivedmods.wclient.network.SignupCredentials
import com.retrivedmods.wclient.network.SignupProfile
import org.json.JSONObject
import java.util.Locale

@Composable
fun MicrosoftSignupDialog(onDismiss: () -> Unit, onLogin: () -> Unit) {
    val context = LocalContext.current
    val saved = remember { runCatching { JSONObject(SecretStorage.load(context,"signup_profile")) }.getOrNull() }
    var email by remember { mutableStateOf("") }
    var first by remember { mutableStateOf(saved?.optString("first","mkrooh") ?: "mkrooh") }
    var last by remember { mutableStateOf(saved?.optString("last","rlp") ?: "rlp") }
    var day by remember { mutableStateOf(saved?.optString("day","") ?: "") }
    var month by remember { mutableStateOf(saved?.optString("month","") ?: "") }
    var year by remember { mutableStateOf(saved?.optString("year","1999") ?: "1999") }
    var country by remember { mutableStateOf(saved?.optString("country","") ?: "") }
    var message by remember { mutableStateOf("") }
    var recoveryPassword by remember { mutableStateOf("") }
    var reveal by remember { mutableStateOf(false) }
    var profile by remember { mutableStateOf<SignupProfile?>(null) }
    var confirmStart by remember { mutableStateOf(false) }
    val validEmail = Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches()
    val currentProfile = profile
    if (currentProfile != null) {
        MicrosoftSignupBrowser(currentProfile) { profile = null }
        return
    }
    fun prepare() {
        require(validEmail) { "أدخل بريدًا صحيحًا تملكه لاستلام كود التحقق." }
        require(first.isNotBlank() && last.isNotBlank()) { "أدخل الاسمين." }
        SignupCredentials.validateDate(day, month, year)
        require(country.uppercase(Locale.ROOT) in Locale.getISOCountries()) { "أدخل رمز بلدك الصحيح من حرفين، مثل IQ أو SA." }
    }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("إنشاء حساب Microsoft") }, text = {
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("التطبيق يعبئ الخطوات المعروفة ويتابعها تلقائيًا. أنت تدخل كود التحقق وتحل الكابتشا في صفحة Microsoft.")
            OutlinedTextField(email, { email=it; recoveryPassword=""; reveal=false }, label={ Text("بريدك لاستلام كود التحقق") },
                keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Email), singleLine=true, modifier=Modifier.fillMaxWidth())
            OutlinedTextField(first, {first=it}, label={Text("الاسم الأول")}, singleLine=true, modifier=Modifier.fillMaxWidth())
            OutlinedTextField(last, {last=it}, label={Text("الاسم الثاني")}, singleLine=true, modifier=Modifier.fillMaxWidth())
            Text("تاريخ ميلادك الصحيح — يُحفظ لهذا الجهاز بعد بدء التسجيل.")
            Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(day,{day=it.filter(Char::isDigit).take(2)},label={Text("اليوم")},singleLine=true,modifier=Modifier.weight(1f),keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number))
                OutlinedTextField(month,{month=it.filter(Char::isDigit).take(2)},label={Text("الشهر")},singleLine=true,modifier=Modifier.weight(1f),keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number))
                OutlinedTextField(year,{year=it.filter(Char::isDigit).take(4)},label={Text("السنة")},singleLine=true,modifier=Modifier.weight(1.3f),keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number))
            }
            OutlinedTextField(country, {country=it.filter(Char::isLetter).take(2).uppercase(Locale.ROOT)}, label={Text("رمز بلدك — IQ للعراق، SA للسعودية")},singleLine=true,modifier=Modifier.fillMaxWidth())
            Text("تُولَّد كلمة مرور قوية وتُحفظ مشفّرة على جهازك قبل البدء. إن عدت بنفس البريد سيستخدم المساعد الكلمة المحفوظة بدل تغييرها.",style=MaterialTheme.typography.bodySmall)
            Button(onClick={
                runCatching { prepare() }.onSuccess { confirmStart=true }.onFailure {message=it.message ?: "تحقق من البيانات."}
            },modifier=Modifier.fillMaxWidth()) { Text("بدء الإنشاء التلقائي") }
            TextButton(enabled=validEmail,onClick={
                runCatching { SignupCredentials.load(context,email.trim()) }.onSuccess {
                    recoveryPassword=it; reveal=false
                    message=if(it.isEmpty()) "لا توجد كلمة مرور محفوظة لهذا البريد؛ تُولّد عند بدء التسجيل." else "هذه كلمة مولّدة لهذا البريد؛ إذا لم تطلب Microsoft كلمة مرور أثناء التسجيل فقد لا تكون استُخدمت للحساب."
                }.onFailure {message="تعذر قراءة كلمة المرور المحفوظة. لا تُنشئ كلمة بديلة تلقائيًا."}
            }) {Text("عرض كلمة المرور المحفوظة لهذا البريد")}
            if(recoveryPassword.isNotEmpty()) {
                OutlinedTextField(recoveryPassword,{},label={Text("كلمة المرور المحفوظة")},readOnly=true,singleLine=true,
                    visualTransformation=if(reveal) VisualTransformation.None else PasswordVisualTransformation(),modifier=Modifier.fillMaxWidth())
                Row {
                    TextButton(onClick={reveal=!reveal}) {Text(if(reveal) "إخفاء" else "إظهار")}
                    TextButton(onClick={
                        val clip=ClipData.newPlainText("Microsoft signup password",recoveryPassword)
                        if(android.os.Build.VERSION.SDK_INT>=33) clip.description.extras=android.os.PersistableBundle().apply {putBoolean("android.content.extra.IS_SENSITIVE",true)}
                        (context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(clip)
                        message="تم نسخ كلمة المرور."
                    }) {Text("نسخ")}
                }
            }
            TextButton(onClick={
                try {context.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://signup.live.com/signup")))}
                catch(_:Exception){message="لا يوجد متصفح متاح."}
            }) {Text("التسجيل يدويًا بمتصفح خارجي")}
            Text("إذا تغيّر تصميم Microsoft أو طلبت خطوة إضافية، سيتوقف المساعد لتكملها. بعد تأكيد إنشاء الحساب، أكمل إعداد Xbox إن طُلب ثم سجّل الدخول هنا. الإضافة لا تنشئ Gamertag تلقائيًا.",style=MaterialTheme.typography.bodySmall)
            if(message.isNotEmpty()) Text(message,color=MaterialTheme.colorScheme.primary)
        }
    },confirmButton={TextButton(onClick=onLogin){Text("تسجيل الدخول بالحساب")}},dismissButton={TextButton(onClick=onDismiss){Text("إغلاق")}})
    if(confirmStart) AlertDialog(onDismissRequest={confirmStart=false},title={Text("بدء التسجيل لدى Microsoft؟")},text={
        Text("سيُرسل بريدك والأسماء وتاريخ الميلاد والبلد وكلمة المرور إلى Microsoft لإنشاء حساب، وقد يُرسل كود تحقق إلى بريدك. راجع صحة البيانات؛ يمكنك إيقاف المساعد أثناء التسجيل. كلمة المرور المحفوظة لا تعني أن الحساب أُنشئ.")
    },confirmButton={TextButton(onClick={
        confirmStart=false
        runCatching {
            prepare()
            val password=SignupCredentials.getOrCreate(context,email.trim())
            SecretStorage.save(context,"signup_profile",JSONObject().put("first",first.trim()).put("last",last.trim())
                .put("day",day).put("month",month).put("year",year).put("country",country).toString())
            profile=SignupProfile(email.trim(),first.trim(),last.trim(),day.toInt().toString(),month.toInt().toString(),year.toInt().toString(),country,password)
        }.onFailure {message=it.message ?: "تعذر حفظ إعدادات التسجيل؛ لم يبدأ المساعد."}
    }){Text("موافق، ابدأ")}},dismissButton={TextButton(onClick={confirmStart=false}){Text("إلغاء")}})
}
