package com.retrivedmods.wclient.game.module.combat

import com.retrivedmods.wclient.game.*
import com.retrivedmods.wclient.game.entity.LocalPlayer
import com.retrivedmods.wclient.game.entity.Player
import com.retrivedmods.wclient.game.friend.FriendManager
import org.cloudburstmc.protocol.bedrock.packet.AnimatePacket
import kotlin.math.*

/** Manual swing ray selection; the server still validates reach. */
class ReachModule : Module("Reach", ModuleCategory.Combat) {
    private var range by floatValue("Blocks", 4f, 4f..50f)
    private var lastSwing = 0L
    override fun beforePacketBound(interceptablePacket: InterceptablePacket) {
        if (!isEnabled || !isSessionCreated) return
        val packet = interceptablePacket.packet
        val player = session.localPlayer
        if (packet !is AnimatePacket || packet.action != AnimatePacket.Action.SWING_ARM || packet.runtimeEntityId != player.runtimeEntityId) return
        val now = System.nanoTime()
        if (now - lastSwing < 50_000_000L) return
        val yaw = Math.toRadians(player.rotationYaw.toDouble())
        val pitch = Math.toRadians(player.rotationPitch.toDouble())
        val lookX = -sin(yaw) * cos(pitch)
        val lookY = -sin(pitch)
        val lookZ = cos(yaw) * cos(pitch)
        val target = session.level.entityMap.values.filterIsInstance<Player>()
            .filter { it !is LocalPlayer && it.runtimeEntityId != player.runtimeEntityId }
            .filterNot { FriendManager.isFriend(it.uuid) }
            .filter { it.distance(player) <= range.coerceIn(4f, 50f) }
            .filter { entity ->
                val dx = (entity.posX - player.posX).toDouble()
                val dy = (entity.posY - player.posY).toDouble()
                val dz = (entity.posZ - player.posZ).toDouble()
                val distance = sqrt(dx * dx + dy * dy + dz * dz)
                distance > 0.001 && (dx * lookX + dy * lookY + dz * lookZ) / distance > cos(Math.toRadians(8.0))
            }.minByOrNull { it.distance(player) } ?: return
        lastSwing = now
        player.attack(target)
    }
}
