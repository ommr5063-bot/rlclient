package com.retrivedmods.wclient.game.module.misc

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import com.retrivedmods.wclient.game.InterceptablePacket
import com.retrivedmods.wclient.game.Module
import com.retrivedmods.wclient.game.ModuleCategory
import org.cloudburstmc.math.matrix.Matrix4f
import org.cloudburstmc.math.vector.Vector2f
import org.cloudburstmc.math.vector.Vector3f
import org.cloudburstmc.protocol.bedrock.packet.PlayerAuthInputPacket
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.ArrayDeque
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Buffers outgoing Bedrock movement input packets while enabled, then releases
 * them in FIFO order. The buffer remains active during release so newly
 * generated movement packets cannot overtake the buffered packets.
 */
class BlinkModule : Module("Blink", ModuleCategory.Misc) {

    private val maxDuration by floatValue("Max Duration (s)", 15f, 1f..30f)
    private val renderGhostTrail by boolValue("Render Ghost Trail", true)
    private val showHudIndicator by boolValue("Show HUD Indicator", true)

    companion object {
        private const val MAX_PACKET_LIMIT = 3000
        private const val MAX_TRAIL_POINTS = 128
        private const val TRAIL_MIN_DISTANCE = 0.25f
        private const val FLUSH_INTERVAL_MS = 20L

        private val lock = Any()
        @Volatile private var renderView: com.retrivedmods.wclient.render.RenderOverlayView? = null

        fun setRenderView(view: com.retrivedmods.wclient.render.RenderOverlayView?) {
            renderView = view
        }
    }

    private val packetQueue = ArrayDeque<PlayerAuthInputPacket>()
    private val positionTrail = ArrayList<Vector3f>()

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var durationJob: Job? = null
    private var flushJob: Job? = null

    // Guarded by lock.
    private var captureActive = false
    private var flushing = false
    private var disconnected = false
    private var autoDisableScheduled = false

    val hasRenderContent: Boolean
        get() = synchronized(lock) {
            (isEnabled || flushing) &&
                ((showHudIndicator && (captureActive || flushing)) ||
                    (renderGhostTrail && positionTrail.isNotEmpty()))
        }

    override fun onEnabled() {
        super.onEnabled()

        durationJob?.cancel()
        flushJob?.cancel()

        synchronized(lock) {
            packetQueue.clear()
            positionTrail.clear()
            captureActive = true
            flushing = false
            disconnected = false
            autoDisableScheduled = false
        }

        renderView?.invalidate()

        durationJob = scope.launch {
            delay((maxDuration * 1000f).toLong().coerceAtLeast(1000L))
            if (isEnabled) {
                sessionOrNull()?.displayClientMessage("§c[Blink] Time limit reached; releasing buffered movement.")
                isEnabled = false
            }
        }
    }

    override fun onDisabled() {
        super.onDisabled()
        durationJob?.cancel()
        durationJob = null

        synchronized(lock) {
            if (disconnected || packetQueue.isEmpty()) {
                captureActive = false
                flushing = false
                packetQueue.clear()
                positionTrail.clear()
                renderView?.invalidate()
                return
            }
            // Keep intercepting while draining so later movement packets do
            // not pass the buffered packets and arrive out of order.
            captureActive = true
            flushing = true
        }

        flushJob?.cancel()
        flushJob = scope.launch(Dispatchers.IO) {
            try {
                while (true) {
                    val finished = synchronized(lock) {
                        if (disconnected || !isSessionCreated) {
                            packetQueue.clear()
                            positionTrail.clear()
                            captureActive = false
                            flushing = false
                            true
                        } else {
                            val next = packetQueue.pollFirst()
                            if (next == null) {
                                captureActive = false
                                flushing = false
                                positionTrail.clear()
                                true
                            } else {
                                // Keep send ordering serialized with packet interception.
                                session.serverBound(next)
                                false
                            }
                        }
                    }

                    renderView?.postInvalidateOnAnimation()
                    if (finished) break
                    delay(FLUSH_INTERVAL_MS)
                }
            } catch (_: CancellationException) {
                // A re-enable or disconnect owns queue cleanup.
            } catch (error: Exception) {
                synchronized(lock) {
                    packetQueue.clear()
                    positionTrail.clear()
                    captureActive = false
                    flushing = false
                }
                sessionOrNull()?.displayClientMessage("§c[Blink] Release failed: ${error.message ?: "network error"}")
            } finally {
                renderView?.postInvalidateOnAnimation()
            }
        }
    }

    override fun beforePacketBound(interceptablePacket: InterceptablePacket) {
        val packet = interceptablePacket.packet as? PlayerAuthInputPacket ?: return

        var scheduleLimitDisable = false
        synchronized(lock) {
            if (!captureActive || disconnected || !isSessionCreated) return

            // Keep memory bounded. If the limit is reached, release the oldest
            // packet before appending the newest one; FIFO order is preserved.
            if (packetQueue.size >= MAX_PACKET_LIMIT) {
                val oldest = packetQueue.pollFirst()
                if (oldest != null) session.serverBound(oldest)
            }

            packetQueue.addLast(packet)
            recordTrailPoint(packet.position)
            interceptablePacket.intercept()

            if (packetQueue.size >= MAX_PACKET_LIMIT && isEnabled && !autoDisableScheduled) {
                autoDisableScheduled = true
                scheduleLimitDisable = true
            }
        }

        if (scheduleLimitDisable) {
            // Module state changes run on the main dispatcher, not the Netty packet thread.
            scope.launch {
                if (isEnabled) {
                    sessionOrNull()?.displayClientMessage("§c[Blink] Packet limit reached; releasing buffer.")
                    isEnabled = false
                }
            }
        }

        renderView?.postInvalidateOnAnimation()
    }

    private fun recordTrailPoint(position: Vector3f) {
        if (!renderGhostTrail) return

        val point = Vector3f.from(position.x, position.y, position.z)
        val last = positionTrail.lastOrNull()

        if (last == null || distance(last, point) >= TRAIL_MIN_DISTANCE) {
            positionTrail.add(point)
            if (positionTrail.size > MAX_TRAIL_POINTS) {
                positionTrail.removeAt(0)
            }
        }
    }

    override fun onDisconnect(reason: String) {
        durationJob?.cancel()
        durationJob = null
        flushJob?.cancel()
        flushJob = null

        synchronized(lock) {
            disconnected = true
            captureActive = false
            flushing = false
            autoDisableScheduled = false
            packetQueue.clear()
            positionTrail.clear()
        }

        renderView?.invalidate()
    }

    fun render(canvas: Canvas) {
        if (!hasRenderContent || !isSessionCreated) return

        val points = synchronized(lock) { positionTrail.toList() }

        if (renderGhostTrail && points.size > 1) {
            drawTrail(canvas, points)
        }

        if (showHudIndicator) {
            val (queued, releasing) = synchronized(lock) {
                packetQueue.size to flushing
            }

            val text = if (releasing) {
                "Blink: releasing $queued packets"
            } else {
                "Blink: $queued packets"
            }

            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textSize = 32f
                typeface = android.graphics.Typeface.create(
                    android.graphics.Typeface.DEFAULT,
                    android.graphics.Typeface.BOLD
                )
                setShadowLayer(4f, 1f, 1f, Color.BLACK)
            }

            val background = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = 0x99000000.toInt()
                style = Paint.Style.FILL
            }

            val left = 18f
            val top = 22f
            val width = paint.measureText(text) + 28f
            canvas.drawRoundRect(left, top, left + width, top + 52f, 10f, 10f, background)
            canvas.drawText(text, left + 14f, top + 35f, paint)
        }
    }

    private fun drawTrail(canvas: Canvas, points: List<Vector3f>) {
        if (!isSessionCreated) return

        val player = session.localPlayer
        val viewProjection = Matrix4f.createPerspective(
            90f,
            canvas.width.toFloat() / canvas.height.coerceAtLeast(1),
            0.1f,
            256f
        ).mul(
            Matrix4f.createTranslation(player.vec3Position)
                .mul(rotateY(-player.rotationYaw - 180f))
                .mul(rotateX(-player.rotationPitch))
                .invert()
        )

        val projected = points.mapNotNull { worldToScreen(it, viewProjection, canvas.width, canvas.height) }
        if (projected.size < 2) return

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(80, 220, 255)
            strokeWidth = 5f
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            setShadowLayer(5f, 0f, 0f, color)
        }

        projected.zipWithNext().forEach { (a, b) ->
            canvas.drawLine(a.x, a.y, b.x, b.y, paint)
        }
    }

    private fun worldToScreen(
        pos: Vector3f,
        matrix: Matrix4f,
        width: Int,
        height: Int
    ): Vector2f? {
        val rw = matrix.get(3, 0) * pos.x +
            matrix.get(3, 1) * pos.y +
            matrix.get(3, 2) * pos.z +
            matrix.get(3, 3)

        if (rw <= 0.01f) return null

        val inv = 1f / rw
        val x = width / 2f +
            (matrix.get(0, 0) * pos.x +
                matrix.get(0, 1) * pos.y +
                matrix.get(0, 2) * pos.z +
                matrix.get(0, 3)) * inv * width / 2f
        val y = height / 2f -
            (matrix.get(1, 0) * pos.x +
                matrix.get(1, 1) * pos.y +
                matrix.get(1, 2) * pos.z +
                matrix.get(1, 3)) * inv * height / 2f

        return Vector2f.from(x, y)
    }

    private fun rotateX(angle: Float): Matrix4f {
        val radians = Math.toRadians(angle.toDouble())
        return Matrix4f.from(
            1f, 0f, 0f, 0f,
            0f, cos(radians).toFloat(), -sin(radians).toFloat(), 0f,
            0f, sin(radians).toFloat(), cos(radians).toFloat(), 0f,
            0f, 0f, 0f, 1f
        )
    }

    private fun rotateY(angle: Float): Matrix4f {
        val radians = Math.toRadians(angle.toDouble())
        return Matrix4f.from(
            cos(radians).toFloat(), 0f, sin(radians).toFloat(), 0f,
            0f, 1f, 0f, 0f,
            -sin(radians).toFloat(), 0f, cos(radians).toFloat(), 0f,
            0f, 0f, 0f, 1f
        )
    }

    private fun distance(a: Vector3f, b: Vector3f): Float {
        val dx = a.x - b.x
        val dy = a.y - b.y
        val dz = a.z - b.z
        return sqrt(dx * dx + dy * dy + dz * dz)
    }

    private fun sessionOrNull() = if (isSessionCreated) session else null
}
