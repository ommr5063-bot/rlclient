package com.retrivedmods.wclient.game.module.combat

import com.retrivedmods.wclient.game.*
import com.retrivedmods.wclient.game.entity.LocalPlayer
import com.retrivedmods.wclient.game.entity.Player
import com.retrivedmods.wclient.game.friend.FriendManager
import org.cloudburstmc.protocol.bedrock.packet.AnimatePacket
import org.cloudburstmc.protocol.bedrock.packet.PlayerAuthInputPacket

class KillauraModule : Module("Kill Aura", ModuleCategory.Combat) {
    enum class AttackMode { Automatic, OnAttackButton }
    private var attackMode by enumValue("Attack mode", AttackMode.Automatic, AttackMode::class.java)
    private var rangeValue by floatValue("Reach", 4f, 4f..50f)
    private var cpsValue by intValue("Hits per second", 10, 1..20)
    private var lastAttackTime = 0L
    override fun beforePacketBound(interceptablePacket: InterceptablePacket) {
        if (!isEnabled || !isSessionCreated) return
        val packet = interceptablePacket.packet
        val ready = when (attackMode) {
            AttackMode.Automatic -> packet is PlayerAuthInputPacket
            AttackMode.OnAttackButton -> packet is AnimatePacket && packet.action == AnimatePacket.Action.SWING_ARM && packet.runtimeEntityId == session.localPlayer.runtimeEntityId
        }
        if (!ready) return
        val now = System.nanoTime()
        if (now - lastAttackTime < 1_000_000_000L / cpsValue.coerceIn(1, 20)) return
        val player = session.localPlayer
        val target = session.level.entityMap.values.filterIsInstance<Player>()
            .filter { it !is LocalPlayer && it.runtimeEntityId != player.runtimeEntityId }
            .filterNot { FriendManager.isFriend(it.uuid) }
            .filter { it.distance(player) <= rangeValue.coerceIn(4f, 50f) }
            .filter { (it.attributes["minecraft:health"]?.value ?: 1f) > 0f }
            .minByOrNull { it.distance(player) } ?: return
        lastAttackTime = now
        player.attack(target)
    }
    override fun onDisabled() { lastAttackTime = 0L; super.onDisabled() }
}
