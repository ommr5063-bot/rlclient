package com.retrivedmods.wclient.router.main

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.retrivedmods.wclient.viewmodel.MainScreenViewModel

enum class MainScreenPages(val icon: ImageVector, val content: @Composable () -> Unit) {
    HomePage(Icons.Rounded.Link, { ProxyPageContent() }),
    AccountPage(Icons.Rounded.AccountCircle, { AccountPageContent() }),
    ServerPage(Icons.Rounded.Storage, { ServerPageContent() }),
    RealmsPage(Icons.Rounded.Cloud, { RealmsPageContent() }),
    SettingsPage(Icons.Rounded.Settings, { SettingsPageContent() }),
    AboutPage(Icons.Rounded.Info, { AboutPageContent() })
}
@Composable fun MainScreen() {
    val vm: MainScreenViewModel = viewModel()
    val selected = vm.selectedPage.collectAsStateWithLifecycle().value
    val pages = listOf(MainScreenPages.AccountPage, MainScreenPages.ServerPage, MainScreenPages.HomePage)
    Row(Modifier.fillMaxSize()) {
        NavigationRail {
            Text("RLclient")
            pages.forEach { page ->
                val title = when (page) { MainScreenPages.AccountPage -> "الحسابات"; MainScreenPages.ServerPage -> "السيرفر"; else -> "البروكسي" }
                NavigationRailItem(selected = selected == page, onClick = { vm.selectPage(page) }, icon = { Icon(page.icon, title) }, label = { Text(title) })
            }
        }
        Box(Modifier.weight(1f).fillMaxHeight()) { selected.content() }
    }
}
