package com.retrivedmods.wclient.router.main

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.retrivedmods.wclient.network.ProxySettings
import com.retrivedmods.wclient.service.Services

@Composable fun ProxyPageContent() {
    val context = LocalContext.current
    val initial = remember { runCatching { ProxySettings.load(context) } }
    var expanded by remember { mutableStateOf(false) }
    var enabled by remember { mutableStateOf(initial.getOrNull()?.enabled ?: false) }
    var host by remember { mutableStateOf(initial.getOrNull()?.host ?: "") }
    var port by remember { mutableStateOf((initial.getOrNull()?.port ?: 1080).toString()) }
    var username by remember { mutableStateOf(initial.getOrNull()?.username ?: "") }
    var password by remember { mutableStateOf(initial.getOrNull()?.password ?: "") }
    var message by remember { mutableStateOf(if (initial.isFailure) "أعد إدخال بيانات البروكسي المحفوظة." else "") }
    Column(Modifier.fillMaxSize()) {
        ConnectionStatusCard()
        OutlinedCard(Modifier.fillMaxWidth().padding(8.dp)) {
            TextButton(onClick = { expanded = !expanded }) { Text(if (expanded) "إغلاق إعدادات البروكسي" else "إعداد بروكسي SOCKS5") }
            if (expanded) Column(Modifier.heightIn(max = 220.dp).verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row { Text("استخدام بروكسي خارجي"); Switch(enabled, { enabled = it }, enabled = !Services.isActive) }
                Text("يتطلب SOCKS5 يدعم UDP. إذا فشل البروكسي يتوقف الاتصال.")
                OutlinedTextField(host, { host = it }, label = { Text("عنوان البروكسي") }, singleLine = true, enabled = !Services.isActive)
                OutlinedTextField(port, { port = it.filter(Char::isDigit) }, label = { Text("المنفذ") }, singleLine = true, enabled = !Services.isActive)
                OutlinedTextField(username, { username = it }, label = { Text("اسم المستخدم — اختياري") }, singleLine = true, enabled = !Services.isActive)
                OutlinedTextField(password, { password = it }, label = { Text("كلمة المرور") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), enabled = !Services.isActive)
                Button(onClick = {
                    runCatching { ProxySettings(enabled, host.trim(), port.toIntOrNull() ?: 0, username, password).save(context) }
                        .onSuccess { message = "تم حفظ إعدادات البروكسي." }.onFailure { message = it.message ?: "تعذر الحفظ." }
                }, enabled = !Services.isActive) { Text("حفظ البروكسي") }
                Text(message)
            }
        }
        Text("بعد التشغيل اختر عنوان الشبكة الظاهر أو 127.0.0.1 على الهاتف نفسه. المنفذ 19132. افتح الزر العائم لإعداد الميزات.", modifier = Modifier.padding(horizontal = 12.dp), style = MaterialTheme.typography.bodySmall)
        Box(Modifier.weight(1f)) { HomePageContent() }
    }
}
