package com.retrivedmods.wclient.router.main

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.retrivedmods.wclient.service.Services
import com.retrivedmods.wclient.viewmodel.MainScreenViewModel

@Composable fun ServerPageContent() {
    val vm: MainScreenViewModel = viewModel()
    val settings by vm.captureModeModel.collectAsState()
    var host by remember(settings.serverHostName) { mutableStateOf(settings.serverHostName) }
    var port by remember(settings.serverPort) { mutableStateOf(settings.serverPort.toString()) }
    var message by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("إعداد السيرفر", style = MaterialTheme.typography.headlineMedium)
        OutlinedTextField(host, { host = it }, label = { Text("IP أو عنوان السيرفر") }, singleLine = true, enabled = !Services.isBusy, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(port, { port = it.filter(Char::isDigit) }, label = { Text("المنفذ") }, singleLine = true, enabled = !Services.isBusy)
        Button(onClick = {
            val value = port.toIntOrNull()
            if (host.isBlank() || value == null || value !in 1..65535) message = "أدخل عنوانًا ومنفذًا صالحين."
            else { vm.selectCaptureModeModel(settings.copy(serverHostName = host.trim(), serverPort = value)); message = "تم حفظ السيرفر." }
        }, enabled = !Services.isBusy) { Text("حفظ السيرفر") }
        Text(message)
        Text("أوقف الاتصال قبل تغيير السيرفر.")
        Text("RLclient • نسخة تجريبية مشتقة من WClient بترخيص GPLv3", style = MaterialTheme.typography.bodySmall)
    }
}
