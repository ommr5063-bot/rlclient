package com.retrivedmods.wclient.overlay.hud

import android.view.Gravity
import android.view.WindowManager
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.retrivedmods.wclient.overlay.OverlayManager
import com.retrivedmods.wclient.overlay.OverlayWindow
import java.util.Locale

/** Draggable nearby-player overlay. Tap a row to lock/unlock view rotation to that player. */
class LookOverlay : OverlayWindow() {

    data class NearbyPlayer(val entityId: Long, val name: String, val distance: Float)

    private val params by lazy {
        super.layoutParams.apply {
            width = WindowManager.LayoutParams.WRAP_CONTENT
            height = WindowManager.LayoutParams.WRAP_CONTENT
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 180
            flags = flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        }
    }

    override val layoutParams: WindowManager.LayoutParams
        get() = params

    private val players = mutableStateListOf<NearbyPlayer>()
    private var distanceVisible by mutableStateOf(true)
    private var selectedEntityId by mutableStateOf<Long?>(null)

    companion object {
        val instance by lazy { LookOverlay() }
        @Volatile private var visible = false
        @Volatile private var selectionListener: ((Long?) -> Unit)? = null

        fun setOverlayEnabled(enabled: Boolean) {
            visible = enabled
            try {
                if (enabled) OverlayManager.showOverlayWindow(instance)
                else OverlayManager.dismissOverlayWindow(instance)
            } catch (_: Exception) {
                // Overlay permission/service may not be ready yet.
            }
        }

        fun setSelectionListener(listener: ((Long?) -> Unit)?) {
            selectionListener = listener
        }

        fun updatePlayers(newPlayers: List<NearbyPlayer>, showDistance: Boolean, selectedId: Long?) {
            instance.players.clear()
            instance.players.addAll(newPlayers.take(40))
            instance.distanceVisible = showDistance
            instance.selectedEntityId = selectedId
        }

        fun clearPlayers() {
            instance.players.clear()
            instance.selectedEntityId = null
        }
    }

    @Composable
    override fun Content() {
        Surface(
            color = Color(0xE91A1A1A),
            contentColor = Color.White,
            shape = RoundedCornerShape(10.dp),
            tonalElevation = 6.dp
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .pointerInput(Unit) {
                            detectDragGestures { _, drag ->
                                params.x += drag.x.toInt()
                                params.y += drag.y.toInt()
                                try {
                                    windowManager.updateViewLayout(composeView, params)
                                } catch (_: Exception) { }
                            }
                        }
                        .padding(bottom = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Look · Nearby Players", color = Color(0xFF80CBC4), fontSize = 14.sp)
                    Text("${players.size}", color = Color.LightGray, fontSize = 12.sp)
                }

                if (players.isEmpty()) {
                    Text("No players in range", color = Color.LightGray, fontSize = 12.sp)
                } else {
                    players.forEach { player ->
                        val isSelected = player.entityId == selectedEntityId
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    if (isSelected) Color(0x5532CD70) else Color.Transparent,
                                    RoundedCornerShape(5.dp)
                                )
                                .clickable {
                                    val next = if (isSelected) null else player.entityId
                                    selectedEntityId = next
                                    selectionListener?.invoke(next)
                                }
                                .padding(horizontal = 5.dp, vertical = 5.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                (if (isSelected) "[LOCKED] " else "") + player.name,
                                color = if (isSelected) Color(0xFF7CFF9B) else Color.White,
                                fontSize = 12.sp,
                                modifier = Modifier.weight(1f)
                            )
                            if (distanceVisible) {
                                Text(
                                    String.format(Locale.ROOT, "%.1fm", player.distance),
                                    color = Color(0xFF80CBC4),
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }
                Text("Tap a player to lock view · tap again to unlock", color = Color.Gray, fontSize = 10.sp)
            }
        }
    }
}
