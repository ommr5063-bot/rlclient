package com.retrivedmods.wclient.service

import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import com.retrivedmods.wclient.application.AppContext
import com.retrivedmods.wclient.game.AccountManager
import com.retrivedmods.wclient.game.GameSession
import com.retrivedmods.wclient.game.ModuleManager
import com.retrivedmods.wclient.game.module.visual.ESPModule
import com.retrivedmods.wclient.model.CaptureModeModel
import com.retrivedmods.wclient.network.ProxySettings
import com.retrivedmods.wclient.network.Socks5UdpTunnel
import com.retrivedmods.wclient.overlay.OverlayManager
import com.retrivedmods.wclient.render.RenderOverlayView
import com.retrivedmods.wrelay.WRelay
import com.retrivedmods.wrelay.WRelaySession
import com.retrivedmods.wrelay.address.WAddress
import com.retrivedmods.wrelay.definition.Definitions
import com.retrivedmods.wrelay.listener.*
import com.retrivedmods.wrelay.util.BedrockProbe
import java.util.concurrent.atomic.AtomicLong
import kotlin.concurrent.thread

/** Public status only becomes ready after an actual local RakNet ping succeeds. */
object Services {
    private val handler = Handler(Looper.getMainLooper())
    private val generation = AtomicLong()
    private val lock = Any()
    @Volatile private var connectionTrace: com.retrivedmods.wrelay.util.ConnectionTrace? = null
    var loadingStage by mutableStateOf("لم تبدأ جلسة اللعبة بعد.")
        private set
    fun connectionReport(): String = "RLclient 0.1.7\nprotocol=${detectedProtocolVersion ?: "unknown"}\n${connectionTrace?.snapshot() ?: "No game session received"}"
    private var relay: WRelay? = null
    private var tunnel: Socks5UdpTunnel? = null
    private var renderView: RenderOverlayView? = null
    private var windowManager: WindowManager? = null
    var isActive by mutableStateOf(false)
        private set
    var isStarting by mutableStateOf(false)
        private set
    var isStopping by mutableStateOf(false)
        private set
    val isBusy: Boolean get() = isActive || isStarting || isStopping
    var statusMessage by mutableStateOf("الاتصال متوقف. احفظ السيرفر ثم اضغط تشغيل.")
        private set
    var lastError by mutableStateOf<String?>(null)
        private set
    var detectedProtocolVersion by mutableStateOf<Int?>(null)
    var detectedMinecraftVersion by mutableStateOf<String?>(null)

    fun toggle(context: Context, model: CaptureModeModel) {
        if (isStopping) return
        if (isBusy) off() else start(context.applicationContext, model)
    }

    private fun start(context: Context, model: CaptureModeModel) {
        val host = model.serverHostName.trim()
        if (host.isBlank() || model.serverPort !in 1..65535 || host.contains("://") || host.contains('/')) {
            lastError = "أدخل عنوان السيرفر فقط دون https أو مسار، والمنفذ في خانته."
            return
        }
        if (host in setOf("127.0.0.1", "localhost", "0.0.0.0", "::1") && model.serverPort == 19132) {
            lastError = "هذه خانة السيرفر الحقيقي. ضع 127.0.0.1:19132 في ماينكرافت فقط."
            return
        }
        // A relay without this listener never opens an upstream session.
        // Validate before starting the service; the direct home button bypasses the old login UI.
        val account = AccountManager.selectedAccount
        if (account == null) {
            lastError = "افتح قائمة الحسابات، سجّل الدخول بحساب ماينكرافت واختره، ثم شغّل الاتصال."
            statusMessage = "لم يبدأ الاتصال: لا يوجد حساب محدد."
            return
        }
        val attempt = generation.incrementAndGet()
        lastError = null
        connectionTrace = null
        loadingStage = "بانتظار اتصال ماينكرافت بالبروكسي."
        isStarting = true
        statusMessage = "جارٍ تشغيل البروكسي المحلي وفحص المنفذ…"
        try {
            ContextCompat.startForegroundService(context, Intent(context, RelayService::class.java))
        } catch (error: Throwable) {
            isStarting = false
            lastError = describe(error)
            statusMessage = "تعذر بدء خدمة الاتصال."
            return
        }
        // The selected account was captured on the UI thread before network work.
        thread(name = "RLclient-start") {
            var candidate: WRelay? = null
            var candidateTunnel: Socks5UdpTunnel? = null
            try {
                val proxy = ProxySettings.load(context)
                val remote = if (proxy.enabled) {
                    val next = Socks5UdpTunnel()
                    candidateTunnel = next
                    val endpoint = next.start(proxy.host, proxy.port, proxy.username, proxy.password, host, model.serverPort)
                    WAddress("127.0.0.1", endpoint.port)
                } else WAddress(host, model.serverPort)
                Definitions.loadBlockPalette()
                val next = WRelay(localAddress = WAddress("0.0.0.0", 19132))
                candidate = next
                next.capture(remoteAddress = remote) {
                    initModules(this, attempt)
                    listeners.add(AutoCodecPacketListener(this))
                    listeners.add(OnlineLoginPacketListener(this, account))
                    listeners.add(GamingPacketHandler(this))
                }
                BedrockProbe.ping("127.0.0.1", 19132, 3000)
                synchronized(lock) {
                    check(generation.get() == attempt) { "Connection start cancelled" }
                    relay = candidate
                    tunnel = candidateTunnel
                }
                handler.post {
                    if (generation.get() == attempt) {
                        isStarting = false
                        isActive = true
                        statusMessage = "البروكسي المحلي يستجيب. اختر عنوان الشبكة أو عنوان هذا الهاتف من القائمة أدناه."
                        runCatching { ModuleManager.loadConfig(); OverlayManager.show(context); setupOverlay(context) }
                            .onFailure { lastError = "القائمة العائمة: ${describe(it)}" }
                    }
                }
            } catch (error: Throwable) {
                runCatching { candidate?.stop() }
                candidateTunnel?.close()
                handler.post {
                    if (generation.get() == attempt) {
                        isStarting = false
                        isActive = false
                        statusMessage = "فشل تشغيل البروكسي المحلي."
                        lastError = describe(error)
                        context.stopService(Intent(context, RelayService::class.java))
                    }
                }
            }
        }
    }

    fun off() {
        if (Looper.myLooper() != Looper.getMainLooper()) { handler.post { off() }; return }
        if (isStopping) return
        val attempt = generation.incrementAndGet()
        isStarting = false
        isActive = false
        isStopping = true
        statusMessage = "جارٍ إغلاق الاتصال وتحرير المنفذ…"
        val previous = synchronized(lock) {
            val resources = relay to tunnel
            relay = null; tunnel = null
            resources
        }
        runCatching { ModuleManager.saveConfig() }
        runCatching { OverlayManager.dismiss() }
        removeOverlay()
        AppContext.instance.stopService(Intent(AppContext.instance, RelayService::class.java))
        thread(name = "RLclient-stop") {
            runCatching { previous.first?.stop() }
            previous.second?.close()
            handler.post {
                if (generation.get() == attempt) {
                    isStopping = false
                    statusMessage = "الاتصال متوقف."
                }
            }
        }
    }

    private fun initModules(session: WRelaySession, attempt: Long) {
        connectionTrace = session.trace
        session.trace.record("protocol=${session.server.codec.protocolVersion}")
        session.listeners.add(object : WRelayPacketListener {
            override fun beforeServerBound(packet: org.cloudburstmc.protocol.bedrock.packet.BedrockPacket): Boolean {
                val stage = when (packet) {
                    is org.cloudburstmc.protocol.bedrock.packet.ResourcePacksInfoPacket -> "استُقبلت قائمة موارد السيرفر."
                    is org.cloudburstmc.protocol.bedrock.packet.ResourcePackStackPacket -> "استُقبل ترتيب حزم الموارد."
                    is org.cloudburstmc.protocol.bedrock.packet.StartGamePacket -> "استُقبل بدء العالم."
                    is org.cloudburstmc.protocol.bedrock.packet.PlayStatusPacket -> "حالة الدخول: ${packet.status}"
                    else -> null
                }
                if (stage != null) handler.post { if (generation.get() == attempt) loadingStage = stage }
                return false
            }
            override fun beforeClientBound(packet: org.cloudburstmc.protocol.bedrock.packet.BedrockPacket): Boolean {
                val stage = when (packet) {
                    is org.cloudburstmc.protocol.bedrock.packet.ResourcePackClientResponsePacket -> {
                        session.trace.record("resource-response=${packet.status}")
                        "رد اللعبة على الموارد: ${packet.status}"
                    }
                    is org.cloudburstmc.protocol.bedrock.packet.SetLocalPlayerAsInitializedPacket -> "اكتمل تهيئة اللاعب."
                    else -> null
                }
                if (stage != null) handler.post { if (generation.get() == attempt) loadingStage = stage }
                return false
            }
        })
        val game = GameSession(session)
        session.listeners.add(game)
        session.listeners.add(VersionTrackingListener { protocol, version ->
            handler.post {
                if (generation.get() == attempt) { detectedProtocolVersion = protocol; detectedMinecraftVersion = version }
            }
        })
        session.listeners.add(object : WRelayPacketListener {
            override fun onDisconnect(reason: String) {
                handler.post {
                    if (generation.get() == attempt) lastError = "انقطع اتصال اللعبة: $reason"
                }
            }
        })
        ModuleManager.modules.forEach { it.session = game }
    }

    fun describe(error: Throwable): String {
        val root = generateSequence(error) { it.cause }.take(8).last()
        return "${root.javaClass.simpleName}: ${root.message ?: "خطأ غير معروف"}"
    }

    private fun setupOverlay(context: Context) {
        windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val params = WindowManager.LayoutParams().apply {
            width = WindowManager.LayoutParams.MATCH_PARENT
            height = WindowManager.LayoutParams.MATCH_PARENT
            type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
            format = PixelFormat.TRANSLUCENT
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) { alpha = 0.8f; setFitInsetsTypes(0); setFitInsetsSides(0) }
        }
        val view = RenderOverlayView(context)
        windowManager?.addView(view, params)
        renderView = view
        ESPModule.setRenderView(view)
    }
    private fun removeOverlay() {
        renderView?.let { view -> runCatching { windowManager?.removeView(view) } }
        renderView = null
    }
}
