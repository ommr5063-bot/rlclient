#include <jni.h>
#include <string>
#include <android/log.h>
#include <sys/mman.h>
#include <unistd.h>
#include <cstring>
#include <cerrno>
#include <cinttypes>
#include <limits>
#include <cstdio>

#define LOG_TAG "rBypass_Production_Final"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, VA_ARGS)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, VA_ARGS)

// دالة دقيقة وآمنة لاستخراج عنوان الأساس الحقيقي للمكتبة عبر قراءة خريطة الذاكرة الخاصة بالعملية
static uintptr_t get_module_base_address(const char* module_name) {
if (module_name == nullptr) return 0;

uintptr_t base_addr = 0;  
FILE* fp = fopen("/proc/self/maps", "r");  
if (fp == nullptr) {  
    LOGE("Failed to open /proc/self/maps (errno: %d)", errno);  
    return 0;  
}  

char line[512];  
while (fgets(line, sizeof(line), fp) != nullptr) {  
    if (strstr(line, module_name) != nullptr) {  
        unsigned long start = 0, end = 0;  
        if (sscanf(line, "%lx-%lx", &start, &end) == 2) {  
            base_addr = static_cast<uintptr_t>(start);  
            // أول تطابق يمثل عادةً بداية شريحة التنفيذ (Text Segment) للمكتبة  
            break;  
        }  
    }  
}  

fclose(fp);  
return base_addr;

}

// دالة تعديل الذاكرة الآمنة المانعة للثغرات والـ Overflow
static bool apply_memory_patch_secure(uintptr_t address, const unsigned char* patch_bytes, size_t length) {
if (address == 0 || patch_bytes == nullptr || length == 0) {
LOGE("Invalid patch parameters: address=0x%" PRIxPTR ", length=%zu", address, length);
return false;
}

// فحص Overflow للجمع الأول  
if (length > std::numeric_limits<uintptr_t>::max() - address) {  
    LOGE("Integer overflow detected in address + length.");  
    return false;  
}  
uintptr_t end_address = address + length;  

long page_size = sysconf(_SC_PAGESIZE);  
if (page_size <= 0 || (page_size & (page_size - 1)) != 0) {  
    page_size = 4096; // قيمة افتراضية معيارية آمنة في حال فشل الاستعلام  
}  
uintptr_t ups = static_cast<uintptr_t>(page_size);  

// فحص Overflow لعملية التقريب النهائية  
if (ups - 1 > std::numeric_limits<uintptr_t>::max() - end_address) {  
    LOGE("Integer overflow detected in region_end calculation.");  
    return false;  
}  

uintptr_t page_start = address & ~(ups - 1);  
uintptr_t region_end = (end_address + ups - 1) & ~(ups - 1);  

if (region_end <= page_start) {  
    LOGE("Computed region bounds are invalid.");  
    return false;  
}  

size_t region_size = region_end - page_start;  

// 1. تغيير الصلاحيات للسماح بالكتابة مؤقتاً  
if (mprotect(reinterpret_cast<void*>(page_start), region_size, PROT_READ | PROT_WRITE | PROT_EXEC) != 0) {  
    LOGE("mprotect to RWX failed. errno: %d (%s)", errno, strerror(errno));  
    return false;  
}  

// 2. نسخ التعليمات الجديدة  
std::memcpy(reinterpret_cast<void*>(address), patch_bytes, length);  

// 3. مزامنة ذاكرة التعليمات لمعماريات ARM/AArch64  
#if defined(__aarch64__) || defined(__arm__)  
__clear_cache(reinterpret_cast<void*>(address), reinterpret_cast<void*>(end_address));  
#endif  

// 4. استعادة صلاحيات القراءة والتنفيذ الصارمة (RX) والتحقق الصارم من نجاحها  
if (mprotect(reinterpret_cast<void*>(page_start), region_size, PROT_READ | PROT_EXEC) != 0) {  
    LOGE("CRITICAL: Failed to restore RX protection! errno: %d (%s)", errno, strerror(errno));  
      
    // محاولة طوارئ نهائية للقراءة فقط لمنع ترك الذاكرة بصلاحية كتابة كاملة  
    if (mprotect(reinterpret_cast<void*>(page_start), region_size, PROT_READ) != 0) {  
        LOGE("EMERGENCY LOCKDOWN FAILED COMPLETELY.");  
    }  
    return false; // فشل مؤكد لا رجعة فيه  
}  

return true; // نجاح فعلي موثوق

}

// --- JNI Bridge Exports ---

extern "C" JNIEXPORT jlong JNICALL
Java_com_retrivedmods_wclient_game_BypassManager_nativeGetModuleBaseAddress(JNIEnv* env, jobject thiz, jstring module_name) {
if (module_name == nullptr) return 0L;

const char* native_module = env->GetStringUTFChars(module_name, nullptr);  
if (native_module == nullptr) return 0L;  

uintptr_t base_addr = get_module_base_address(native_module);  
  
if (base_addr != 0) {  
    LOGI("Resolved %s base address at: 0x%" PRIxPTR, native_module, base_addr);  
} else {  
    LOGE("Failed to resolve base address for module: %s", native_module);  
}  

env->ReleaseStringUTFChars(module_name, native_module);  
return static_cast<jlong>(base_addr);

}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_retrivedmods_wclient_game_BypassManager_nativeInitRendezvousBypass(JNIEnv* env, jobject thiz, jlong base_address) {
if (base_address == 0L) {
LOGE("nativeInitRendezvousBypass: Received zero base address.");
return JNI_FALSE;
}

uintptr_t target_base = static_cast<uintptr_t>(base_address);  
  
// مثال للإزاحة المستهدفة داخل المكتبة  
uintptr_t target_offset = 0x00FE4280;  
uintptr_t target_address = target_base + target_offset;  

// تعليمات ARM64 لإرجاع القيمة true (MOV W0, #1; RET)  
unsigned char patch_bytes[] = { 0x20, 0x00, 0x80, 0xD2, 0xC0, 0x03, 0x5F, 0xD6 };  

// تنفيذ الباتش الفعلي والتحقق من النتيجة دون أي نجاح وهمي  
if (apply_memory_patch_secure(target_address, patch_bytes, sizeof(patch_bytes))) {  
    LOGI("rBypass successfully injected and verified at address: 0x%" PRIxPTR, target_address);  
    return JNI_TRUE;  
}  

LOGE("rBypass injection failed during memory patching.");  
return JNI_FALSE;

}