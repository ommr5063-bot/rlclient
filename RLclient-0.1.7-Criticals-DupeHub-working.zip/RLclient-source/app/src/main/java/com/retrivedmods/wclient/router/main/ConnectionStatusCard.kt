package com.retrivedmods.wclient.router.main

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.retrivedmods.wclient.network.ProxySettings
import com.retrivedmods.wclient.network.Socks5UdpTunnel
import com.retrivedmods.wclient.service.Services
import com.retrivedmods.wclient.viewmodel.MainScreenViewModel
import com.retrivedmods.wrelay.util.BedrockProbe
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable fun ConnectionStatusCard() {
    val context = LocalContext.current
    val vm: MainScreenViewModel = viewModel()
    val model by vm.captureModeModel.collectAsState()
    val scope = rememberCoroutineScope()
    var checking by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf("") }
    var addresses by remember { mutableStateOf(com.retrivedmods.wclient.network.RelayAddresses.available()) }
    LaunchedEffect(Services.isActive) { addresses = com.retrivedmods.wclient.network.RelayAddresses.available() }
    OutlinedCard(Modifier.fillMaxWidth().padding(8.dp)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(Services.statusMessage)
            val selectedAccount = com.retrivedmods.wclient.game.AccountManager.selectedAccount
            Text(if (selectedAccount == null) "الحساب: غير محدد — سجّل الدخول واختر حسابًا من قائمة الحسابات."
                else "الحساب المحدد: ${selectedAccount.mcChain.displayName}", style = MaterialTheme.typography.bodySmall)
            if (Services.isActive) {
                Text(Services.loadingStage, style = MaterialTheme.typography.bodySmall)
                TextButton(onClick = {
                    (context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                        .setPrimaryClip(ClipData.newPlainText("RLclient connection report", Services.connectionReport()))
                    result = "تم نسخ تقرير الاتصال؛ يحتوي أسماء ومراحل الحزم فقط، دون بيانات الحساب."
                }) { Text("نسخ تقرير الاتصال") }
            }
            Services.lastError?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            if (Services.isStarting) LinearProgressIndicator(Modifier.fillMaxWidth())
            Text("السيرفر المحفوظ: ${model.serverHostName}:${model.serverPort}", style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!Services.isBusy) Button(onClick = {
                    if (!Settings.canDrawOverlays(context)) {
                        context.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:${context.packageName}")))
                        result = "اسمح بالظهور فوق التطبيقات ثم ارجع واضغط تشغيل."
                    } else Services.toggle(context, model)
                }) { Text("تشغيل البروكسي المحلي") }
                Button(enabled = !checking && !Services.isStarting, onClick = {
                    checking = true; result = "جارٍ فحص استجابة السيرفر…"
                    scope.launch {
                        result = withContext(Dispatchers.IO) {
                            runCatching {
                                val proxy = ProxySettings.load(context)
                                val response = if (proxy.enabled) {
                                    Socks5UdpTunnel().use { tunnel ->
                                        val address = tunnel.start(proxy.host, proxy.port, proxy.username, proxy.password,
                                            model.serverHostName, model.serverPort)
                                        BedrockProbe.ping("127.0.0.1", address.port, 4000)
                                    }
                                } else BedrockProbe.ping(model.serverHostName, model.serverPort, 4000)
                                val fields = response.split(';')
                                "السيرفر يستجيب${if (proxy.enabled) " عبر البروكسي" else " مباشرة"}: ${fields.getOrNull(1)} • ${fields.getOrNull(3)}"
                            }.getOrElse { "فشل فحص السيرفر: ${Services.describe(it)}. تحقق من عنوان Bedrock والمنفذ؛ بعض السيرفرات تحجب الفحص." }
                        }
                        checking = false
                    }
                }) { Text("فحص السيرفر") }
                if (Services.isBusy) OutlinedButton(onClick = { Services.off() }) { Text("إيقاف الاتصال") }
            }
            if (result.isNotEmpty()) Text(result, style = MaterialTheme.typography.bodySmall)
            if (Services.isActive) {
                addresses.forEach { address ->
                    TextButton(onClick = {
                        (context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                            .setPrimaryClip(ClipData.newPlainText("RLclient IP", address.host))
                        result = "تم نسخ ${address.host} — المنفذ 19132."
                    }) { Text("${address.label}: ${address.host}:19132 — نسخ IP") }
                }
                TextButton(onClick = { addresses = com.retrivedmods.wclient.network.RelayAddresses.available() }) { Text("تحديث عناوين الشبكة") }
            }
        }
    }
}
