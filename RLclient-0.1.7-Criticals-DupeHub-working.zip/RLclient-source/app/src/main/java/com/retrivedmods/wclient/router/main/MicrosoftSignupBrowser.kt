package com.retrivedmods.wclient.router.main

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceError
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebSettings
import android.os.SystemClock
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.retrivedmods.wclient.network.SignupProfile
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import org.json.JSONArray
import org.json.JSONObject
import kotlin.coroutines.resume

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun MicrosoftSignupBrowser(profile: SignupProfile, onClose: () -> Unit) {
    val context = LocalContext.current
    var webView by remember { mutableStateOf<WebView?>(null) }
    var pageHost by remember { mutableStateOf("signup.live.com") }
    var status by remember { mutableStateOf("جارٍ فتح تسجيل Microsoft…") }
    var running by remember { mutableStateOf(true) }
    var submitted by remember { mutableStateOf("[]") }
    val script = remember { context.assets.open("signup-auto.js").bufferedReader().use { it.readText() } }
    val data = remember(profile) { JSONObject(profile.json()).put("runId", java.util.UUID.randomUUID().toString()).toString() }
    val deadline = remember { SystemClock.elapsedRealtime() + 10 * 60 * 1000L }
    LaunchedEffect(webView, running) {
        val view = webView ?: return@LaunchedEffect
        if (!running) return@LaunchedEffect
        while (SystemClock.elapsedRealtime() < deadline) {
            val uri = Uri.parse(view.url ?: "")
            if (uri.scheme == "https" && uri.host == "signup.live.com") {
                val raw = suspendCancellableCoroutine<String> { continuation ->
                    view.evaluateJavascript("($script)($data, $submitted)") { value ->
                        if (continuation.isActive) continuation.resume(value ?: "null")
                    }
                }
                val response = runCatching { JSONObject(raw) }.getOrNull()
                if (response != null) {
                    // Receipts contain phase names only, never form contents or credentials.
                    val phases = response.optJSONArray("submitted") ?: JSONArray()
                    val allowed = setOf("email", "password", "name", "birth")
                    submitted = JSONArray((0 until phases.length()).map { phases.optString(it) }.filter { it in allowed }).toString()
                    val state = response.optString("status")
                    status = when {
                        state == "captcha" -> "حل الكابتشا في الصفحة؛ المساعد لا يحلها ولا يتجاوزها."
                        state == "verification" -> "أدخل كود التحقق واضغط تأكيده داخل صفحة Microsoft. بعدها يكمل المساعد الخطوات المعروفة."
                        state == "storage-error" -> "تعذر حفظ تقدم الخطوات؛ أكمل يدويًا لتجنب إرسال الطلب مرتين."
                        state == "review-error" -> "Microsoft تعرض رسالة تحتاج مراجعتك. لن يعيد المساعد إرسال نفس الخطوة."
                        state == "review-fields" -> "هذه الخطوة تحتاج مراجعة: حقل إضافي أو قيمة مختلفة. أكملها يدويًا في الصفحة."
                        state == "manual-step" -> "لم يتعرّف المساعد على هذه الخطوة. أكملها يدويًا؛ الحساب لا يُعد منشأً حتى تؤكده Microsoft."
                        state == "awaiting-next-page" -> "تمت متابعة هذه الخطوة مرة واحدة. بانتظار Microsoft؛ إذا ظهرت رسالة راجعها في الصفحة."
                        state == "waiting-button" -> "بانتظار جاهزية زر المتابعة لدى Microsoft."
                        state.startsWith("filled-") -> "تمت تعبئة الخطوة المعروفة؛ جارٍ التحضير للمتابعة."
                        state.startsWith("submitted-") -> "تم الضغط على التالي للخطوة المعروفة؛ بانتظار رد Microsoft."
                        else -> "المتابعة التلقائية متاحة في صفحة إنشاء الحساب الرسمية فقط."
                    }
                }
            }
            delay(1250)
        }
        running = false
        status = "انتهت مهلة المساعد. أكمل يدويًا في الصفحة؛ لا يُعاد إرسال طلب التسجيل تلقائيًا."
    }
    DisposableEffect(Unit) {
        onDispose { webView?.stopLoading(); webView?.destroy() }
    }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        BackHandler { if (webView?.canGoBack() == true) { running=false; webView?.goBack() } else onClose() }
        Surface(Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxSize()) {
                Text("تسجيل Microsoft • $pageHost", modifier = Modifier.padding(8.dp), style = MaterialTheme.typography.titleSmall)
                Text("التعبئة والمتابعة تلقائيتان للخطوات المعروفة. كود التحقق والكابتشا عليك.", modifier = Modifier.padding(horizontal = 8.dp), style = MaterialTheme.typography.bodySmall)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    TextButton(onClick = { running = !running }, enabled = SystemClock.elapsedRealtime() < deadline) {
                        Text(if (running) "إيقاف المساعد" else "استئناف")
                    }
                    TextButton(onClick = {
                        running = false
                        try { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://signup.live.com/signup"))) }
                        catch (_: Exception) { status = "لا يوجد متصفح متاح." }
                    }) { Text("متصفح خارجي") }
                    TextButton(onClick = onClose) { Text("رجوع") }
                }
                Text(status, Modifier.padding(horizontal = 8.dp), style = MaterialTheme.typography.bodySmall)
                AndroidView(modifier = Modifier.fillMaxWidth().weight(1f), factory = {
                    WebView(context).apply {
                        webView = this
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.allowFileAccess = false
                        settings.allowContentAccess = false
                        settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                        CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                        webViewClient = object : WebViewClient() {
                            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                                if (!request.isForMainFrame) return false
                                val uri = request.url
                                val host = uri.host ?: ""
                                val microsoftPage = host in setOf("signup.live.com", "login.live.com", "account.live.com",
                                    "account.microsoft.com", "login.microsoftonline.com", "www.xbox.com")
                                if (uri.scheme == "https" && microsoftPage) return false
                                running = false
                                status = "هذه الصفحة خارج مسار التسجيل؛ استخدم المتصفح الخارجي لفتحها."
                                return true
                            }
                            override fun onPageFinished(view: WebView, url: String) {
                                pageHost = Uri.parse(url).host ?: ""
                                if (pageHost != "signup.live.com") status = "أكمل الخطوة في صفحة Microsoft ثم ارجع. فتحها لا يؤكد إنشاء الحساب."
                            }
                            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                                if (request.isForMainFrame) { running=false; status = "تعذر تحميل الصفحة. جرّب المتصفح الخارجي." }
                            }
                        }
                        // No JS bridge, code/CAPTCHA capture, certificate bypass or retry loop.
                        loadUrl("https://signup.live.com/signup")
                    }
                })
            }
        }
    }
}
