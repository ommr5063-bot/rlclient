package com.retrivedmods.wclient.service

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

/** Keeps the user-started relay alive while Minecraft is in the foreground. */
class RelayService : Service() {
    companion object {
        private const val CHANNEL = "rlclient_connection"
        private const val NOTIFICATION = 41
        private const val STOP = "ai.dreammobile.rlclient.STOP"
    }
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL, "RLclient connection", NotificationManager.IMPORTANCE_LOW))
        val stopIntent = Intent(this, RelayService::class.java).setAction(STOP)
        val stop = PendingIntent.getService(this, 0, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("RLclient")
            .setContentText("اتصال اللعبة قيد التشغيل").setOngoing(true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "إيقاف", stop).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(NOTIFICATION, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(NOTIFICATION, notification)
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == STOP) { if (Services.isBusy) Services.off() else stopSelf() }
        return START_NOT_STICKY
    }
    override fun onDestroy() {
        if (Services.isBusy) Services.off()
        super.onDestroy()
    }
}
