package com.retrivedmods.wclient.game.module.combat

import com.retrivedmods.wclient.game.Module
import com.retrivedmods.wclient.game.ModuleCategory

/** Passive placeholder: intentionally performs no packet spoofing or replay. */
class RBypassModule : Module("rbypass", ModuleCategory.Combat) {

    override fun onEnabled() {
        super.onEnabled()
        if (isSessionCreated) {
            session.displayClientMessage(
                "§7[RBypass] Passive placeholder: no packet modification or protection bypass is performed."
            )
        }
    }
}
