package com.retrivedmods.wclient.game.module.misc

import com.retrivedmods.wclient.game.InterceptablePacket
import com.retrivedmods.wclient.game.Module
import com.retrivedmods.wclient.game.ModuleCategory
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.cloudburstmc.protocol.bedrock.packet.BedrockPacket
import org.cloudburstmc.protocol.bedrock.packet.InventoryTransactionPacket
import org.cloudburstmc.protocol.bedrock.packet.PlayerAuthInputPacket
import java.util.ArrayDeque

/**
 * Buffers selected outgoing movement/inventory packets and releases them in FIFO
 * order when disabled or when a safety limit is reached. This module is intended
 * to be used separately from Blink.
 */
class BurstModule : Module("Burst", ModuleCategory.Misc) {

    private val bufferMovement by boolValue("Buffer Movement", true)
    private val bufferInventory by boolValue("Buffer Inventory", true)
    private val maxDurationSeconds by intValue("Max Buffer Duration (s)", 5, 1..10)
    private val maxPackets by intValue("Max Buffered Packets", 512, 32..2048)

    companion object {
        private const val RELEASE_INTERVAL_MS = 1L
        private const val HARD_PACKET_LIMIT = 2048
    }

    private val queueLock = Any()
    private val packetQueue = ArrayDeque<BedrockPacket>()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    // Guarded by queueLock.
    private var capturing = false
    private var flushing = false
    private var disconnected = false
    private var durationJob: Job? = null
    private var flushJob: Job? = null

    override fun onEnabled() {
        super.onEnabled()
        durationJob?.cancel()
        flushJob?.cancel()

        synchronized(queueLock) {
            packetQueue.clear()
            disconnected = false
            capturing = true
            flushing = false
        }

        durationJob = scope.launch {
            delay(maxDurationSeconds.coerceIn(1, 10) * 1000L)
            if (isEnabled) {
                sessionOrNull()?.displayClientMessage("§c[Burst] Buffer duration reached; releasing packets.")
                isEnabled = false
            }
        }
    }

    override fun onDisabled() {
        super.onDisabled()
        durationJob?.cancel()
        durationJob = null

        val shouldFlush = synchronized(queueLock) {
            if (disconnected || packetQueue.isEmpty() || !isSessionCreated) {
                packetQueue.clear()
                capturing = false
                flushing = false
                false
            } else {
                // Keep capturing selected packets until the FIFO queue is empty,
                // preventing newer selected packets from overtaking buffered ones.
                capturing = true
                flushing = true
                true
            }
        }

        if (shouldFlush) startFlush()
    }

    override fun beforePacketBound(interceptablePacket: InterceptablePacket) {
        val packet = interceptablePacket.packet
        val shouldBuffer = (bufferMovement && packet is PlayerAuthInputPacket) ||
            (bufferInventory && packet is InventoryTransactionPacket)
        if (!shouldBuffer) return

        var forceDisable = false
        synchronized(queueLock) {
            if (!capturing || disconnected || !isSessionCreated) return

            val configuredLimit = maxPackets.coerceIn(32, HARD_PACKET_LIMIT)
            if (packetQueue.size >= configuredLimit) {
                // Do not grow without bound. The current packet is also buffered
                // only if there is still room; then the module is disabled to flush.
                if (packetQueue.size < HARD_PACKET_LIMIT) {
                    packetQueue.addLast(packet)
                    interceptablePacket.intercept()
                }
                forceDisable = isEnabled
            } else {
                packetQueue.addLast(packet)
                interceptablePacket.intercept()
                if (packetQueue.size >= configuredLimit) forceDisable = isEnabled
            }
        }

        if (forceDisable) {
            scope.launch(Dispatchers.Main.immediate) {
                if (isEnabled) {
                    sessionOrNull()?.displayClientMessage("§c[Burst] Buffer limit reached; releasing packets.")
                    isEnabled = false
                }
            }
        }
    }

    private fun startFlush() {
        flushJob?.cancel()
        flushJob = scope.launch {
            try {
                while (true) {
                    val finished = synchronized(queueLock) {
                        if (disconnected || !isSessionCreated) {
                            packetQueue.clear()
                            capturing = false
                            flushing = false
                            true
                        } else {
                            val next = packetQueue.pollFirst()
                            if (next == null) {
                                capturing = false
                                flushing = false
                                true
                            } else {
                                // Sending while holding the same lock serializes
                                // release with packet interception and preserves FIFO order.
                                session.serverBound(next)
                                false
                            }
                        }
                    }
                    if (finished) break
                    delay(RELEASE_INTERVAL_MS)
                }
            } catch (_: CancellationException) {
                // A subsequent enable/disconnect owns queue cleanup.
            } catch (error: Exception) {
                synchronized(queueLock) {
                    packetQueue.clear()
                    capturing = false
                    flushing = false
                }
                sessionOrNull()?.displayClientMessage(
                    "§c[Burst] Release failed: ${error.message ?: "network error"}"
                )
            }
        }
    }

    override fun onDisconnect(reason: String) {
        durationJob?.cancel()
        durationJob = null
        flushJob?.cancel()
        flushJob = null
        synchronized(queueLock) {
            disconnected = true
            capturing = false
            flushing = false
            packetQueue.clear()
        }
    }

    private fun sessionOrNull() = if (isSessionCreated) session else null
}
