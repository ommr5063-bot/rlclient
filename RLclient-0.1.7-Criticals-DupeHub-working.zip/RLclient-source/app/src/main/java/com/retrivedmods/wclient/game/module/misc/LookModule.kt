package com.retrivedmods.wclient.game.module.misc

import com.retrivedmods.wclient.game.InterceptablePacket
import com.retrivedmods.wclient.game.Module
import com.retrivedmods.wclient.game.ModuleCategory
import com.retrivedmods.wclient.game.entity.LocalPlayer
import com.retrivedmods.wclient.game.entity.Player
import com.retrivedmods.wclient.overlay.hud.LookOverlay
import org.cloudburstmc.math.vector.Vector3f
import org.cloudburstmc.protocol.bedrock.packet.PlayerAuthInputPacket
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.atan2
import kotlin.math.hypot

/** Nearby-player list with click-to-select and packet-based view rotation. */
class LookModule : Module("Look", ModuleCategory.Misc) {

    private val minRender by floatValue("Min Render", 5f, 1f..50f)
    private val maxRender by floatValue("Max Render", 100f, 10f..200f)
    private val updateInterval by intValue("Update Interval (ms)", 250, 50..3000)
    private val showDistance by boolValue("Show Distance", true)
    private val aimSpeed by floatValue("Aim Speed", 100f, 1f..100f)
    private enum class AimPoint { HEAD, CHEST, FEET }
    private val aimPoint by enumValue("Aim Point", AimPoint.CHEST, AimPoint::class.java)

    @Volatile private var selectedTargetId: Long? = null
    private var updateScope: CoroutineScope? = null

    override fun onEnabled() {
        super.onEnabled()
        selectedTargetId = null
        LookOverlay.setOverlayEnabled(true)
        LookOverlay.setSelectionListener { entityId -> selectedTargetId = entityId }
        if (isSessionCreated) startUpdating()
    }

    override fun onDisabled() {
        stopUpdating()
        selectedTargetId = null
        LookOverlay.clearPlayers()
        LookOverlay.setSelectionListener(null)
        LookOverlay.setOverlayEnabled(false)
        super.onDisabled()
    }

    override fun onDisconnect(reason: String) {
        stopUpdating()
        selectedTargetId = null
        LookOverlay.clearPlayers()
        LookOverlay.setSelectionListener(null)
        LookOverlay.setOverlayEnabled(false)
    }

    private fun startUpdating() {
        stopUpdating()
        updateScope = CoroutineScope(Dispatchers.Main.immediate + SupervisorJob()).also { scope ->
            scope.launch {
                while (isActive && isEnabled && isSessionCreated) {
                    refreshPlayers()
                    delay(updateInterval.coerceIn(50, 3000).toLong())
                }
            }
        }
    }

    private fun stopUpdating() {
        updateScope?.cancel()
        updateScope = null
    }

    private fun refreshPlayers() {
        if (!isEnabled || !isSessionCreated) return

        val localPlayer = session.localPlayer
        val minDistance = minRender.coerceAtLeast(0f)
        val maxDistance = maxRender.coerceAtLeast(minDistance).coerceAtMost(200f)

        val nearby = session.level.entityMap.values
            .asSequence()
            .filterIsInstance<Player>()
            .filter { it !is LocalPlayer && it.runtimeEntityId != localPlayer.runtimeEntityId }
            .mapNotNull { player ->
                val distance = player.distance(localPlayer)
                if (!distance.isFinite() || distance !in minDistance..maxDistance) return@mapNotNull null
                val name = session.level.playerMap[player.uuid]?.name?.toString()
                    ?.takeIf { it.isNotBlank() } ?: player.username
                LookOverlay.NearbyPlayer(player.runtimeEntityId, name, distance)
            }
            .sortedBy { it.distance }
            .toList()

        val currentSelection = selectedTargetId
        if (currentSelection != null && nearby.none { it.entityId == currentSelection }) {
            selectedTargetId = null
        }
        LookOverlay.updatePlayers(nearby, showDistance, selectedTargetId)
    }

    override fun beforePacketBound(interceptablePacket: InterceptablePacket) {
        if (!isEnabled || !isSessionCreated) return
        val packet = interceptablePacket.packet as? PlayerAuthInputPacket ?: return
        val targetId = selectedTargetId ?: return
        val player = session.localPlayer
        val target = session.level.entityMap[targetId] as? Player

        if (target == null || target is LocalPlayer) {
            selectedTargetId = null
            return
        }

        val distance = target.distance(player)
        val minDistance = minRender.coerceAtLeast(0f)
        val maxDistance = maxRender.coerceAtLeast(minDistance).coerceAtMost(200f)
        if (!distance.isFinite() || distance !in minDistance..maxDistance) {
            selectedTargetId = null
            return
        }

        val verticalOffset = when (aimPoint) {
            AimPoint.HEAD -> 1.62f
            AimPoint.CHEST -> 1.0f
            AimPoint.FEET -> 0.15f
        }
        val from = player.vec3Position
        val to = target.vec3Position.add(0f, verticalOffset, 0f)
        val dx = to.x - from.x
        val dy = to.y - from.y
        val dz = to.z - from.z
        val horizontalDistance = hypot(dx, dz)
        if (horizontalDistance < 0.0001f && kotlin.math.abs(dy) < 0.0001f) return

        // Bedrock rotation vector is (pitch, yaw, headYaw).
        val desiredYaw = Math.toDegrees(atan2(-dx.toDouble(), dz.toDouble())).toFloat()
        val desiredPitch = (-Math.toDegrees(atan2(dy.toDouble(), horizontalDistance.toDouble())))
            .toFloat().coerceIn(-90f, 90f)
        val currentRotation = packet.rotation
        val factor = (aimSpeed / 100f).coerceIn(0.01f, 1f)
        val yaw = approachAngle(currentRotation.y, desiredYaw, factor)
        val pitch = currentRotation.x + (desiredPitch - currentRotation.x) * factor

        packet.rotation = Vector3f.from(pitch, yaw, yaw)
    }

    private fun approachAngle(current: Float, target: Float, factor: Float): Float {
        val difference = ((target - current + 540f) % 360f) - 180f
        return current + difference * factor
    }
}
