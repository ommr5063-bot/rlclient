package com.retrivedmods.wclient.network

import java.net.Inet4Address
import java.net.NetworkInterface

object RelayAddresses {
    data class Entry(val host: String, val label: String)
    fun available(): List<Entry> {
        val network = runCatching {
            NetworkInterface.getNetworkInterfaces().asSequence()
                .filter { it.isUp && !it.isLoopback }
                .sortedBy { if (it.name.startsWith("wlan") || it.name.startsWith("wifi")) 0 else 1 }
                .flatMap { adapter ->
                    adapter.inetAddresses.asSequence().filterIsInstance<Inet4Address>()
                        .filter { it.isSiteLocalAddress && !it.isLoopbackAddress }
                        .map { Entry(it.hostAddress ?: "", "عنوان الشبكة (${adapter.name})") }
                }.filter { it.host.isNotBlank() }.distinctBy { it.host }.toList()
        }.getOrDefault(emptyList())
        return network + Entry("127.0.0.1", "على هذا الهاتف فقط")
    }
}
