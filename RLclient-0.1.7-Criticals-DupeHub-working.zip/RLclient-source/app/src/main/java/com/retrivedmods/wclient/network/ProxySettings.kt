package com.retrivedmods.wclient.network

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

object SecretStorage {
    private const val KEY = "rlclient_local_credentials"
    @Synchronized private fun key(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(KEY, null) as? SecretKey)?.let { return it }
        return KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore").apply {
            init(KeyGenParameterSpec.Builder(KEY, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build())
        }.generateKey()
    }
    fun save(context: Context, name: String, value: String) {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.ENCRYPT_MODE, key()) }
        val encrypted = cipher.doFinal(value.toByteArray(Charsets.UTF_8))
        check(context.getSharedPreferences("encrypted_credentials", Context.MODE_PRIVATE).edit()
            .putString(name, Base64.encodeToString(cipher.iv + encrypted, Base64.NO_WRAP)).commit())
    }
    fun load(context: Context, name: String): String {
        val value = context.getSharedPreferences("encrypted_credentials", Context.MODE_PRIVATE).getString(name, null) ?: return ""
        val bytes = Base64.decode(value, Base64.NO_WRAP)
        require(bytes.size >= 28) { "Stored credential cannot be decrypted" }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, bytes.copyOfRange(0, 12))) }
        return cipher.doFinal(bytes.copyOfRange(12, bytes.size)).toString(Charsets.UTF_8)
    }
}
data class ProxySettings(val enabled: Boolean, val host: String, val port: Int, val username: String, val password: String) {
    companion object {
        fun load(context: Context): ProxySettings {
            val prefs = context.getSharedPreferences("upstream_proxy", Context.MODE_PRIVATE)
            return ProxySettings(prefs.getBoolean("enabled", false), prefs.getString("host", "") ?: "", prefs.getInt("port", 1080),
                prefs.getString("username", "") ?: "", SecretStorage.load(context, "proxy_password"))
        }
    }
    fun save(context: Context) {
        require(port in 1..65535) { "Invalid proxy port" }
        require(!enabled || host.isNotBlank()) { "Proxy host is required" }
        SecretStorage.save(context, "proxy_password", password)
        check(context.getSharedPreferences("upstream_proxy", Context.MODE_PRIVATE).edit().putBoolean("enabled", enabled)
            .putString("host", host.trim()).putInt("port", port).putString("username", username).commit())
    }
}
