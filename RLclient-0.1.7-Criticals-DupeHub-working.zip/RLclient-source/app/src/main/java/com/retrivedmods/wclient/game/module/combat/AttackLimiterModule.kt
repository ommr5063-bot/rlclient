package com.retrivedmods.wclient.game.module.combat

import com.retrivedmods.wclient.game.InterceptablePacket
import com.retrivedmods.wclient.game.Module
import com.retrivedmods.wclient.game.ModuleCategory
import org.cloudburstmc.protocol.bedrock.data.inventory.transaction.InventoryTransactionType
import org.cloudburstmc.protocol.bedrock.packet.InventoryTransactionPacket
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock

class AttackLimiterModule : Module("attacklimiter", ModuleCategory.Combat) {

    private enum class Mode {
        CPS_LIMITER,
        UNRESTRICTED
    }

    private val mode by enumValue("Mode", Mode.CPS_LIMITER, Mode::class.java)
    private val enableCpsLimit by boolValue("Enable CPS Limit", true)
    private val cpsLimit by intValue("CPS Limit", 8, 1..20)

    private val acceptedHits = AtomicLong(0L)
    private val droppedHits = AtomicLong(0L)
    private var lastClickTimeNs = 0L
    private val lock = ReentrantLock()

    override fun onEnabled() {
        resetSessionStats()
        super.onEnabled()
    }

    override fun onDisabled() {
        resetSessionStats()
        super.onDisabled()
    }

    private fun resetSessionStats() = lock.withLock {
        acceptedHits.set(0L)
        droppedHits.set(0L)
        lastClickTimeNs = 0L
    }

    fun getAcceptedCount(): Long = acceptedHits.get()
    fun getDroppedCount(): Long = droppedHits.get()

    override fun beforePacketBound(interceptablePacket: InterceptablePacket) {
        if (!isEnabled) return

        val packet = interceptablePacket.packet as? InventoryTransactionPacket ?: return
        if (packet.transactionType != InventoryTransactionType.ITEM_USE_ON_ENTITY || packet.actionType != 1) return

        lock.withLock {
            when (mode) {
                Mode.CPS_LIMITER -> {
                    if (!enableCpsLimit) {
                        acceptedHits.incrementAndGet()
                        return
                    }

                    val limit = cpsLimit.coerceIn(1, 20)
                    val minIntervalNs = 1_000_000_000L / limit
                    val now = System.nanoTime()
                    val previous = lastClickTimeNs

                    if (previous != 0L && now - previous < minIntervalNs) {
                        droppedHits.incrementAndGet()
                        interceptablePacket.intercept()
                        return
                    }

                    lastClickTimeNs = now
                    acceptedHits.incrementAndGet()
                }

                Mode.UNRESTRICTED -> acceptedHits.incrementAndGet()
            }
        }
    }
}
