package com.retrivedmods.wclient.game.module.combat

import com.retrivedmods.wclient.game.InterceptablePacket
import com.retrivedmods.wclient.game.Module
import com.retrivedmods.wclient.game.ModuleCategory
import org.cloudburstmc.protocol.bedrock.data.inventory.transaction.InventoryTransactionType
import org.cloudburstmc.protocol.bedrock.packet.InventoryTransactionPacket

/**
 * Safe attack-rate control for entity-hit transactions.
 *
 * Bedrock does not expose a client-side "critical hit" flag in
 * InventoryTransactionPacket. This module therefore does not spoof falling,
 * rewrite movement packets, or claim to force critical hits. It only limits
 * the rate of entity attack transactions when enabled.
 */
class AutoCritModule : Module("autocrit", ModuleCategory.Combat) {

    private val cpsLimit by intValue("CPS Limit", 8, 1..10)
    private var lastAttackTime = 0L

    override fun onEnabled() {
        lastAttackTime = 0L
        super.onEnabled()
    }

    override fun onDisabled() {
        lastAttackTime = 0L
        super.onDisabled()
    }

    override fun beforePacketBound(interceptablePacket: InterceptablePacket) {
        val packet = interceptablePacket.packet as? InventoryTransactionPacket ?: return

        // Inventory transactions also carry normal inventory operations.
        // Only inspect actual entity-use transactions so inventory actions
        // and container clicks are never throttled.
        if (packet.transactionType != InventoryTransactionType.ITEM_USE_ON_ENTITY ||
            packet.actionType != 1
        ) return

        val now = System.nanoTime()
        val minIntervalNanos = 1_000_000_000L / cpsLimit.coerceIn(1, 10)
        val previous = lastAttackTime

        if (previous != 0L && now - previous < minIntervalNanos) {
            interceptablePacket.intercept()
            return
        }

        lastAttackTime = now
    }
}
