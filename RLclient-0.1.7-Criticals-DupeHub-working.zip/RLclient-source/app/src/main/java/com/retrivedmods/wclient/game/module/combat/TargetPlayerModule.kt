package com.retrivedmods.wclient.game.module.combat

import com.retrivedmods.wclient.game.*
import com.retrivedmods.wclient.game.entity.LocalPlayer
import com.retrivedmods.wclient.game.entity.Player
import com.retrivedmods.wclient.game.friend.FriendManager
import org.cloudburstmc.protocol.bedrock.packet.EntityEventPacket
import org.cloudburstmc.protocol.bedrock.packet.MovePlayerPacket
import org.cloudburstmc.protocol.bedrock.packet.PlayerAuthInputPacket
import org.cloudburstmc.protocol.bedrock.data.entity.EntityEventType
import java.util.UUID

class TargetPlayerModule : Module("Target Player", ModuleCategory.Combat) {
    var maxDistance by floatValue("Player list distance", 50f, 1f..500f)
    private var cps by intValue("Hits per second", 10, 1..20)
    data class Selection(val id: Long, val uuid: UUID)
    @Volatile var selection: Selection? = null
        private set
    private var lastAttack = 0L
    fun nearbyPlayers(): List<Player> {
        if (!isSessionCreated || !isEnabled) return emptyList()
        val player = session.localPlayer
        return session.level.entityMap.values.filterIsInstance<Player>()
            .filter { it !is LocalPlayer && it.runtimeEntityId != player.runtimeEntityId }
            .filterNot { FriendManager.isFriend(it.uuid) }
            .filter { it.distance(player) <= maxDistance.coerceIn(1f, 500f) }
            .sortedBy { it.distance(player) }
    }
    fun select(player: Player?) { selection = player?.let { Selection(it.runtimeEntityId, it.uuid) }; lastAttack = 0L }
    override fun beforePacketBound(interceptablePacket: InterceptablePacket) {
        if (!isEnabled || !isSessionCreated) return
        val key = selection ?: return
        val packet = interceptablePacket.packet
        if (packet is EntityEventPacket && packet.runtimeEntityId == key.id && packet.type == EntityEventType.DEATH) {
            selection = null; return
        }
        if (packet !is PlayerAuthInputPacket) return
        val target = session.level.entityMap[key.id] as? Player
        if (target == null || target.uuid != key.uuid || (target.attributes["minecraft:health"]?.value ?: 1f) <= 0f) { selection = null; return }
        val player = session.localPlayer
        if (target.distance(player) > maxDistance.coerceIn(1f, 500f)) { selection = null; return }
        val destination = target.vec3Position.add(0f, 0f, 0.8f)
        packet.delta = destination.sub(player.vec3Position)
        packet.position = destination
        player.move(destination)
        session.clientBound(MovePlayerPacket().apply {
            runtimeEntityId = player.runtimeEntityId
            position = destination
            rotation = player.vec3Rotation
            mode = MovePlayerPacket.Mode.NORMAL
            setOnGround(false)
            tick = player.tickExists
        })
        val now = System.nanoTime()
        if (now - lastAttack >= 1_000_000_000L / cps.coerceIn(1, 20)) { lastAttack = now; player.attack(target) }
    }
    override fun onDisabled() { selection = null; lastAttack = 0L; super.onDisabled() }
}
