# Look module

`LookModule.kt` is registered in `game/ModuleManager.kt` under Misc.

- The draggable `LookOverlay` lists nearby players inside Min/Max Render.
- Tap a player row to select it; tap the same row again to clear the selection.
- While selected, outgoing `PlayerAuthInputPacket` rotations are adjusted toward the selected player's configured aim point (Head, Chest, or Feet).
- Aim Speed controls interpolation: 100 is immediate; lower values turn more gradually.
- The selection is cleared when the target leaves the configured range, disappears, the module is disabled, or the session disconnects.

The module changes outgoing view rotation only. It does not teleport the player or automatically attack the target.
