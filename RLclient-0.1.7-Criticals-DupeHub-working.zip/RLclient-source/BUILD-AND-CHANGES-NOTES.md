# RLclient source delivery notes

## Included changes
- AttackLimiterModule is registered in ModuleManager. It limits local outgoing entity-attack transactions in CPS-Limiter mode and offers an Unrestricted local mode.
- LookModule and its overlay selection integration are present.
- DebugModule reports player/entity counts, nearest nearby target information, and packet-type totals. It does not label packet timing as Geyser ping.
- RBypassModule is a passive placeholder; it does not modify, spoof, delay, duplicate, or replay packets.
- BlinkModule was left unchanged.
- BurstModule was added and registered separately. It buffers outgoing PlayerAuthInputPacket and InventoryTransactionPacket packets, with configurable packet types, a bounded queue, a maximum capture duration, and FIFO release when disabled or when the configured limit is reached. Use Burst separately from Blink.

## Not included
- FreeOModule and VisualStretchModule were cancelled and are not present.
- FreeOModule and VisualStretchModule were cancelled and are not present.

## Build status
A local Kotlin compile was attempted with `./gradlew :app:compileDebugKotlin --offline --no-daemon`, but Gradle could not start because the Gradle 8.13 distribution was not cached and network DNS access to `services.gradle.org` was unavailable. Therefore this archive is source-delivered but not build-verified in this environment.
