package com.retrivedmods.wrelay.codec

import org.cloudburstmc.protocol.bedrock.codec.BedrockCodec

/** Exact protocol matching. Never pretend an unsupported protocol is compatible. */
object CodecRegistry {
    private val versions = mapOf(898 to "1.21.130", 924 to "1.26.0", 944 to "1.26.10",
        975 to "1.26.20", 1001 to "1.26.30", 2168 to "1.26.44", 2169 to "1.26.45",
        2193 to "1.26.50", 2225 to "1.26.60")
    private val codecs: Map<Int, BedrockCodec> = versions.mapValues { (protocol, _) ->
        val suffix = if (protocol == 2168) "_hotfix4" else ""
        val type = Class.forName("org.cloudburstmc.protocol.bedrock.codec.v$protocol.Bedrock_v$protocol$suffix")
        type.getField("CODEC").get(null) as BedrockCodec
    }
    fun getCodecByProtocol(protocolVersion: Int): BedrockCodec? = codecs[protocolVersion]
    fun getClosestCodec(protocolVersion: Int): BedrockCodec = codecs[protocolVersion]
        ?: throw IllegalArgumentException("Unsupported Minecraft protocol: $protocolVersion")
    fun getLatestCodec(): BedrockCodec = codecs.getValue(versions.keys.max())
    fun getMinecraftVersion(protocolVersion: Int): String? = versions[protocolVersion]
}
