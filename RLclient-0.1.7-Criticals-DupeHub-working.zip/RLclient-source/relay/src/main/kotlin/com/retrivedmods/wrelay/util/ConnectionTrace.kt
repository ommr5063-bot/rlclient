package com.retrivedmods.wrelay.util

/** Bounded metadata only; never stores payloads, JWTs, chat, or account fields. */
class ConnectionTrace {
    private val entries = ArrayDeque<String>()
    private val counts = mutableMapOf<String, Int>()
    private val started = System.nanoTime()
    @Synchronized fun record(event: String) {
        val count = (counts[event] ?: 0) + 1
        counts[event] = count
        if (count > 3 && count % 100 != 0) return
        val elapsed = (System.nanoTime() - started) / 1_000_000L
        entries.addLast("${elapsed}ms $event${if (count > 1) " x$count" else ""}")
        while (entries.size > 80) entries.removeFirst()
        if (counts.size > 256) counts.clear()
    }
    @Synchronized fun snapshot(): String = entries.joinToString("\n")
}
