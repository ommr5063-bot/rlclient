package com.retrivedmods.wrelay.util;

import java.io.IOException;
import java.net.*;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.concurrent.ThreadLocalRandom;

/** Read-only RakNet ping with bounded retries; never logs into the game. */
public final class BedrockProbe {
    private static final byte[] MAGIC = {0, (byte)255, (byte)255, 0, (byte)254, (byte)254, (byte)254, (byte)254,
            (byte)253, (byte)253, (byte)253, (byte)253, 0x12, 0x34, 0x56, 0x78};
    public static String ping(String host, int port, int timeoutMillis) throws IOException {
        if (port < 1 || port > 65535) throw new IOException("Invalid port: " + port);
        InetSocketAddress address = new InetSocketAddress(InetAddress.getByName(host), port);
        long token = ThreadLocalRandom.current().nextLong();
        byte[] request = ByteBuffer.allocate(33).put((byte)1).putLong(token).put(MAGIC)
                .putLong(ThreadLocalRandom.current().nextLong()).array();
        try (DatagramSocket socket = new DatagramSocket()) {
            socket.connect(address);
            long deadline = System.nanoTime() + timeoutMillis * 1_000_000L;
            while (System.nanoTime() < deadline) {
                socket.send(new DatagramPacket(request, request.length));
                long retryAt = Math.min(deadline, System.nanoTime() + 750_000_000L);
                while (System.nanoTime() < retryAt) {
                    socket.setSoTimeout((int)Math.max(1L, (retryAt - System.nanoTime()) / 1_000_000L));
                    byte[] bytes = new byte[8192];
                    DatagramPacket reply = new DatagramPacket(bytes, bytes.length);
                    try { socket.receive(reply); } catch (SocketTimeoutException timeout) { break; }
                    int size = reply.getLength();
                    if (size < 35 || bytes[0] != 0x1c) continue;
                    ByteBuffer input = ByteBuffer.wrap(bytes, 0, size);
                    input.get();
                    if (input.getLong() != token) continue;
                    input.getLong();
                    byte[] magic = new byte[16]; input.get(magic);
                    if (!Arrays.equals(magic, MAGIC)) continue;
                    int length = input.getShort() & 65535;
                    if (length > input.remaining()) continue;
                    byte[] advertisement = new byte[length]; input.get(advertisement);
                    String text = new String(advertisement, StandardCharsets.UTF_8);
                    if (text.startsWith("MCPE;")) return text;
                }
            }
        }
        throw new SocketTimeoutException("No Bedrock UDP reply from " + host + ":" + port);
    }
    private BedrockProbe() {}
}
