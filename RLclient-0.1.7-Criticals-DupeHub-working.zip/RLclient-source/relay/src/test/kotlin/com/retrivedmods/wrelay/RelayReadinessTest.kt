package com.retrivedmods.wrelay

import com.retrivedmods.wrelay.address.WAddress
import com.retrivedmods.wrelay.util.BedrockProbe
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.Assertions.*
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.SocketTimeoutException

class RelayReadinessTest {
    private fun freePort(): Int = DatagramSocket(0).use { it.localPort }

    @Test fun `actual relay advertises 26_60 after bind and can restart`() {
        val port = freePort()
        repeat(2) {
            val relay = WRelay(localAddress = WAddress("127.0.0.1", port))
            try {
                relay.capture(WAddress("127.0.0.1", 19134)) {}
                assertTrue(relay.isRunning)
                val pong = BedrockProbe.ping("127.0.0.1", port, 2000)
                assertTrue(pong.startsWith("MCPE;RLclient;2225;1.26.60;"), pong)
            } finally { relay.stop() }
            assertFalse(relay.isRunning)
        }
    }

    @Test fun `wildcard listener replies through network address as well as loopback`() {
        val networkAddress = java.net.NetworkInterface.getNetworkInterfaces().asSequence()
            .filter { it.isUp && !it.isLoopback }
            .flatMap { it.inetAddresses.asSequence() }
            .filterIsInstance<java.net.Inet4Address>()
            .firstOrNull { it.isSiteLocalAddress } ?: return
        val port = freePort()
        val relay = WRelay(localAddress = WAddress("0.0.0.0", port))
        try {
            relay.capture(WAddress("127.0.0.1", 19134)) {}
            assertTrue(BedrockProbe.ping(networkAddress.hostAddress, port, 2000).startsWith("MCPE;RLclient;"))
            assertTrue(BedrockProbe.ping("127.0.0.1", port, 2000).startsWith("MCPE;RLclient;"))
        } finally { relay.stop() }
    }

    @Test fun `occupied port is reported instead of ready`() {
        DatagramSocket(0, InetAddress.getByName("127.0.0.1")).use { occupied ->
            val relay = WRelay(localAddress = WAddress("127.0.0.1", occupied.localPort))
            try {
                assertThrows(Throwable::class.java) { relay.capture(WAddress("127.0.0.1", 19134)) {} }
                assertFalse(relay.isRunning)
            } finally { relay.stop() }
        }
    }

    @Test fun `silent UDP endpoint is not advertised as a game server`() {
        DatagramSocket(0, InetAddress.getByName("127.0.0.1")).use { silent ->
            assertThrows(SocketTimeoutException::class.java) { BedrockProbe.ping("127.0.0.1", silent.localPort, 250) }
        }
    }
}
