package com.retrivedmods.wrelay;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.ByteBufUtil;
import io.netty.buffer.Unpooled;
import io.netty.channel.embedded.EmbeddedChannel;
import org.cloudburstmc.protocol.bedrock.PacketDirection;
import org.cloudburstmc.protocol.bedrock.codec.*;
import org.cloudburstmc.protocol.bedrock.codec.v2225.Bedrock_v2225;
import org.cloudburstmc.protocol.bedrock.netty.BedrockPacketWrapper;
import org.cloudburstmc.protocol.bedrock.netty.codec.packet.BedrockPacketCodec_v3;
import org.cloudburstmc.protocol.bedrock.packet.*;
import org.cloudburstmc.protocol.common.util.VarInts;
import org.junit.jupiter.api.Test;
import java.util.ArrayList;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

public class LoadingPassthroughTest {
    private static <T extends BedrockPacket> BedrockPacketSerializer<T> broken() {
        return new BedrockPacketSerializer<T>() {
            public void serialize(ByteBuf buffer, BedrockCodecHelper helper, T packet) {}
            public void deserialize(ByteBuf buffer, BedrockCodecHelper helper, T packet) {
                buffer.readByte(); // Simulate a newer-format packet failing after partial consumption.
                throw new IllegalArgumentException("test decoder mismatch");
            }
        };
    }
    private static ByteBuf wire(int id) {
        ByteBuf buffer = Unpooled.buffer();
        VarInts.writeUnsignedInt(buffer, id | (1 << 10) | (2 << 12));
        buffer.writeBytes(new byte[]{42, 0, -1, 17, 99});
        return buffer;
    }
    private static EmbeddedChannel channel(BedrockPacketCodec_v3 codec, PacketDirection direction) {
        EmbeddedChannel channel = new EmbeddedChannel();
        if (direction != null) channel.attr(PacketDirection.ATTRIBUTE).set(direction);
        channel.pipeline().addLast(codec);
        return channel;
    }
    @Test void failedResourceDecodeRetainsEntirePayloadAndHeader() {
        BedrockPacketCodec_v3 codec = new BedrockPacketCodec_v3();
        codec.setCodec(Bedrock_v2225.CODEC.toBuilder().updateSerializer(ResourcePacksInfoPacket.class, broken()).build());
        List<Integer> notices = new ArrayList<>();
        codec.enableRelayPassthrough((id, kind) -> notices.add(id));
        int id = codec.getPacketId(new ResourcePacksInfoPacket());
        EmbeddedChannel channel = channel(codec, PacketDirection.SERVER_BOUND);
        ByteBuf input = wire(id);
        byte[] expected = ByteBufUtil.getBytes(input);
        try {
            assertTrue(channel.writeInbound(input));
            BedrockPacketWrapper packet = channel.readInbound();
            assertInstanceOf(UnknownPacket.class, packet.getPacket());
            assertEquals(1, packet.getSenderSubClientId());
            assertEquals(2, packet.getTargetSubClientId());
            assertArrayEquals(new byte[]{42, 0, -1, 17, 99}, ByteBufUtil.getBytes(((UnknownPacket)packet.getPacket()).getPayload()));
            assertEquals(List.of(id), notices);
            assertTrue(channel.writeOutbound(packet));
            BedrockPacketWrapper forwarded = channel.readOutbound();
            assertArrayEquals(expected, ByteBufUtil.getBytes(forwarded.getPacketBuffer()));
            forwarded.release();
        } finally { channel.finishAndReleaseAll(); }
        assertEquals(0, input.refCnt());
    }
    @Test void partialChunkDecodeDoesNotLeakRetainedData() {
        BedrockPacketSerializer<ResourcePackChunkDataPacket> serializer = new BedrockPacketSerializer<>() {
            public void serialize(ByteBuf buffer, BedrockCodecHelper helper, ResourcePackChunkDataPacket packet) {}
            public void deserialize(ByteBuf buffer, BedrockCodecHelper helper, ResourcePackChunkDataPacket packet) {
                packet.setData(buffer.readRetainedSlice(1));
                throw new IllegalArgumentException("partial chunk");
            }
        };
        BedrockPacketCodec_v3 codec = new BedrockPacketCodec_v3();
        codec.setCodec(Bedrock_v2225.CODEC.toBuilder().updateSerializer(ResourcePackChunkDataPacket.class, serializer).build());
        codec.enableRelayPassthrough((id, kind) -> {});
        EmbeddedChannel channel = channel(codec, PacketDirection.SERVER_BOUND);
        ByteBuf input = wire(codec.getPacketId(new ResourcePackChunkDataPacket()));
        try {
            assertTrue(channel.writeInbound(input));
            BedrockPacketWrapper packet = channel.readInbound();
            assertInstanceOf(UnknownPacket.class, packet.getPacket());
            packet.release();
        } finally { channel.finishAndReleaseAll(); }
        assertEquals(0, input.refCnt(), "Failed serializer must release its partially retained data");
    }
    @Test void ordinaryEndpointsStillRejectUnparseablePackets() {
        BedrockPacketCodec_v3 codec = new BedrockPacketCodec_v3();
        codec.setCodec(Bedrock_v2225.CODEC.toBuilder().updateSerializer(ResourcePacksInfoPacket.class, broken()).build());
        EmbeddedChannel channel = channel(codec, null);
        try { assertThrows(Exception.class, () -> channel.writeInbound(wire(codec.getPacketId(new ResourcePacksInfoPacket())))); }
        finally { channel.finishAndReleaseAll(); }
    }
    @Test void loginRemainsStrictEvenInRelayMode() {
        BedrockPacketCodec_v3 codec = new BedrockPacketCodec_v3();
        codec.setCodec(Bedrock_v2225.CODEC.toBuilder().updateSerializer(LoginPacket.class, broken()).build());
        codec.enableRelayPassthrough((id, kind) -> fail("Login must not be passed through"));
        EmbeddedChannel channel = channel(codec, null);
        try { assertThrows(Exception.class, () -> channel.writeInbound(wire(codec.getPacketId(new LoginPacket())))); }
        finally { channel.finishAndReleaseAll(); }
    }
    @Test void wrongDirectionIsNotTreatedAsCompatibilityFailure() {
        BedrockPacketCodec_v3 codec = new BedrockPacketCodec_v3();
        codec.setCodec(Bedrock_v2225.CODEC);
        codec.enableRelayPassthrough((id, kind) -> fail("Wrong direction must remain rejected"));
        EmbeddedChannel channel = channel(codec, PacketDirection.CLIENT_BOUND);
        try { assertThrows(Exception.class, () -> channel.writeInbound(wire(codec.getPacketId(new ResourcePacksInfoPacket())))); }
        finally { channel.finishAndReleaseAll(); }
    }
}
