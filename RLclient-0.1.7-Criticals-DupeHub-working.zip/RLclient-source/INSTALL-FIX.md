# RLclient 0.1.3 — installation package revision

Version code: 4. Package: `ai.dreammobile.rlclient.connectionfix`.

The reported Android package-parsing error has not been reproduced on a device. The previously delivered 0.1.2 APK passes ZIP CRC, APK v2 signature verification and Android manifest parsing in the build environment. Its size is 87,256,292 bytes. No specific phone-side cause has been established.

This build changes the installation packaging:

- Compress DEX entries using Android's supported legacy DEX packaging rather than storing the large DEX files uncompressed. This reduces the file transferred to the phone; it does not remove features or lower the minimum Android version.
- Explicitly enable APK v1, v2 and v3 signing in the debug configuration actually used for delivered builds.
- Keep the same package name and signing certificate as 0.1.1/0.1.2, with a higher version code, permitting an in-place update.
- Retain the 0.1.2 loading/connection fixes. The report now displays 0.1.3.

Android 9/API 28 or newer is still required. Runtime support for Minecraft is unchanged. Device installation and an authenticated in-game session remain unverified.

Build with JDK 17, Android SDK 36, and the existing signing keystore supplied through `RLCLIENT_DEBUG_KEYSTORE`:

```sh
bash ./gradlew --no-daemon --max-workers=2 -Dorg.gradle.jvmargs=-Xmx2048m :app:assembleDebug
```

If parsing still fails, obtain the exact downloaded file size, phone model and screenshot/full installer message before further package revisions. Do not uninstall the working old version or erase its data as a diagnostic shortcut.
