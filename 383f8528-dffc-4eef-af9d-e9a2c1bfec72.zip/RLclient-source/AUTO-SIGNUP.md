# RLclient 0.1.7 — automatic progression for recognized Microsoft signup steps

Retains the 0.1.3 networking implementation. Extends the native signup screen with names `mkrooh` and `rlp`, birth year `1999` (confirmed by the requester), required actual day/month and country, and an encrypted reusable generated password per normalized email. Profile defaults are saved encrypted on the device; email is entered for each run. No generated account credential exists in this source or build environment.

The app presents an explicit confirmation before opening the automatic signup flow: submitted personal data, possible verification email and the ability to pause are disclosed. The WebView remains visible. The user supplies verification codes and solves CAPTCHA within Microsoft's page. No external account was created in development.

`signup-auto.js` recognizes visible email, new-password, first/last-name and birth/country fields on HTTPS `signup.live.com`. It fills known fields, waits for reactive form state, and clicks only a unique button labelled Next/Continue/التالي/متابعة. Unknown fields, ambiguous actions, field validation failures, required unchecked consents and visible error messages stop automatic submission. It does not click Create/Accept buttons or automate Xbox gamertag selection. A different Microsoft flow may still need manual action.

Only phase-name receipts are stored in sessionStorage before a click and returned to the native UI; credentials are not returned. This avoids automatic resend after reload or a lost callback. Private storage failure halts submission. The native assistant polls while active, with a 10-minute bound, a pause control, origin checks in both native code and JS, and no JavaScript bridge. There is no automatic retry of a submitted phase.

A generated password is stored in Android Keystore-backed encrypted storage before opening registration. The same email reuses that value, so a retry does not silently replace the intended password. The UI can reveal/copy it explicitly. If Microsoft uses passwordless signup and never requests a password, the stored value may not become the account's password; it is not evidence the account exists. The app does not mark creation successful: the user waits for Microsoft confirmation, completes Xbox setup if requested, then uses the existing login flow.

## Verification and limits

`python3 tests/test_signup_auto.py` tests automatic transitions for four supported stages using local fixtures; delay before clicking, one click per phase and retained receipts after reload; stops for verification/CAPTCHA, errors, additional fields and required consent; preservation of manual edits, ambiguous actions, storage failure and origin isolation. It also checks recognition and filling of the current real Microsoft email field with a reserved example address, with exactly one helper invocation and no Next click.

No live form submission, verification email, account creation, later real registration stages or Android device signup was tested. Later-stage selectors are fixture-tested and are deliberately conservative. Microsoft may change its page or require a system browser. Manual/browser fallback remains available, and the requested end-to-end email/code/CAPTCHA-only experience is not guaranteed for every signup flow.
