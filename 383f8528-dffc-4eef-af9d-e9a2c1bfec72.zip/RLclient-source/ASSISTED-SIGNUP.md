# RLclient 0.1.6 — assisted Microsoft signup

Adds a WebView-based signup helper on top of the 0.1.5 official signup entry. The connection implementation remains the restored 0.1.3 implementation.

The user enters an existing email and optionally their first/last name, then opens **بدء التسجيل مع التعبئة**. On `https://signup.live.com` the helper fills empty, visible, recognized email/name inputs. A bounded MutationObserver handles delayed rendering; **تعبئة البيانات** reruns the helper if later steps render beyond its window. User-entered values are never overwritten. Data is JSON-encoded rather than interpolated as JavaScript source. It is kept in memory, not preferences.

The helper does not submit forms, click Next, accept terms, fill a password, invent a birthdate, create a gamertag, or read/solve verification codes or CAPTCHA. It does not claim account creation succeeded. These actions remain in Microsoft's page under user control. The existing separate login flow adds the account to RLclient after the user completes registration.

The WebView does not expose a JavaScript bridge or local files, does not bypass certificate errors, and blocks main-frame navigation outside the specified Microsoft/Xbox HTTPS hosts. Page scripts and HTTPS verification frames are handled by WebView. If Microsoft refuses embedded browsers or its verification UI does not work on a device, the existing system-browser option remains available; browser sessions are separate and the user may need to start again there.

## Validation

`python3 tests/test_signup_assist.py` checks fixture-only field filling, preservation of manual edits, origin restrictions, delayed mounting and absence of form submission/code/password/CAPTCHA/date changes. It also opens the current real Microsoft initial signup page and fills an unroutable example email without submitting or clicking Next. No account is created and no verification email is requested. Only the initial real email field has been verified live; later name-field mappings are tested on fixtures and remain dependent on Microsoft's page layout.

Android build and APK signature/alignment validation are performed separately. Real Android WebView behavior, CAPTCHA and completion of Microsoft/Xbox account registration are not device-tested.
