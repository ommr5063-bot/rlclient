# RLclient 0.1.2 — resource loading investigation

This update addresses a confirmed packet-loss path in the relay. It is not yet a verified fix for the reported freeze across all servers: no Android device or authenticated live CubeCraft session is available in the build environment.

## Changes

- Require a selected Minecraft account before starting the relay. The 0.1.1 direct-start button allowed a null account and silently omitted OnlineLoginPacketListener, so no upstream connection was ever opened. The app now explains how to sign in/select an account instead of announcing a ready relay that cannot log in.
- Opt-in passthrough for same-protocol relay sessions: if a gameplay packet cannot be deserialized, forward its original payload instead of dropping it. Packet bytes consumed before the exception are restored. Normal endpoints remain strict, as do login, play-status, encryption and network-settings packets. Direction checks remain active.
- Delay module packet hooks until the game sends SetLocalPlayerAsInitialized, keeping combat/movement packet modifications out of the loading phase.
- A bounded connection report contains packet IDs/types, resource-response states and exception class names, never packet contents, account tokens or chat. Use **نسخ تقرير الاتصال** on the home screen after reproducing a freeze. The home screen also displays the latest decoded loading stage.
- Version 0.1.2-loading-fix, code 3, package ai.dreammobile.rlclient.connectionfix. Use the same signing key as 0.1.1 to allow an in-place update.

## Validation

Run from the project root with JDK 17 and Android SDK 36:

```sh
bash ./gradlew --no-daemon --max-workers=2 -Dorg.gradle.jvmargs=-Xmx2048m :relay:test --tests com.retrivedmods.wrelay.LoadingPassthroughTest --tests com.retrivedmods.wrelay.RelayReadinessTest :app:assembleDebug
```

The regression tests exercise a serializer that fails after reading part of a resource packet, byte-for-byte preservation, retained-buffer cleanup, strict authentication and packet direction, plus the relay readiness tests. Device installation, live Microsoft login and CubeCraft gameplay must still be checked on a phone.

## Phone check

1. Install over 0.1.1; no uninstall or account reset is required if the installed version has the same certificate.
2. Stop any old relay, then start this version with the existing server settings.
3. Retry entering CubeCraft from Minecraft using the displayed local IP and port 19132.
4. If loading still stalls, return without stopping the relay, tap **نسخ تقرير الاتصال**, and send that report along with the Minecraft version shown by the game.

Original GPLv3 license and attribution are retained. Signing credentials are not distributed with source.
