# RLclient 0.1.5 — restore 0.1.3 networking and official signup entry

This source was extracted from the previously delivered `RLclient-0.1.3-source.zip`, rather than reverting individual changes from 0.1.4. It retains 0.1.3 networking, protocol libraries, authentication flow, proxy settings, and the original proxy page. The 0.1.4 checker and latency UI/classes are absent. The Services connection report only changes its displayed version string.

Version code 6 and the same application ID/signing certificate allow updating over 0.1.4 while keeping application data. Returning to the 0.1.3 code does not reset saved server, proxy, or account preferences, and does not establish the cause of the reported connection regression.

The Accounts page adds **إنشاء حساب Microsoft**:

- Optional existing-email field and explicit copy button. No email is automatically sent by RLclient or stored in preferences.
- Opens https://signup.live.com/ with Android Custom Tabs, with a normal-browser fallback option. Custom Tabs depend on a compatible installed browser.
- All password, personal-data, verification-code and CAPTCHA entry happens on Microsoft's site. No DOM injection, unattended signup, fake profile data, automatic CAPTCHA solving, or token extraction is added.
- The user returns and explicitly starts the existing account-login flow to add their new account. Closing the browser is not considered proof that an account was created.
- Xbox profile/gamertag setup is handled by Microsoft when required. This is not an automated new-account API and does not make account creation a two-step email/code-only operation.

Official reference: https://support.microsoft.com/en-us/account-billing/how-to-create-a-new-microsoft-account-a84675c3-3e9e-17cf-2911-3d56b15c0aaf

## Checks

Source comparison with the 0.1.3 archive, packet-loading and relay-readiness tests, APK build, manifest version check, signature verification and alignment check. No Android device is available for UI/signup or authenticated game-server testing. No Microsoft account was created during development.
