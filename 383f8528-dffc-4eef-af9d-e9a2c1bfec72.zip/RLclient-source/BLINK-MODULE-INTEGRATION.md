# Blink module integration

Added `BlinkModule.kt` to the RLclient Android/Kotlin source.

- Buffers outgoing `PlayerAuthInputPacket` packets (the Bedrock movement/input packet used by this codebase).
- Uses `GameSession.serverBound()` when releasing packets; in this project that is the game-to-server route.
- Keeps interception active during gradual release so later movement packets cannot overtake buffered packets.
- Bounds the packet queue and the ghost trail.
- Clears queued packets on disconnect rather than sending stale movement into a later connection.
- Draws the HUD indicator and projected ghost trail through the existing `RenderOverlayView`.

The module is registered under the Misc category in `ModuleManager`.
