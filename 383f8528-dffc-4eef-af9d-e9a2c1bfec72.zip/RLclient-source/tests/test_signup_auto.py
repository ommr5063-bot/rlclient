"""Test automatic registration transitions on local fixtures only.
Live Microsoft inspection fills first email field once; never clicks Next there.
"""
from pathlib import Path
import os, uuid
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
script=(ROOT/'app/src/main/assets/signup-auto.js').read_text()
base={'email':'rlclient-flow-test@example.test','firstName':'mkrooh','lastName':'rlp','day':'12','month':'4','year':'1999','country':'IQ','password':'Test-only-R7!not-a-real-password'}
button='<button type="button" onclick="window.clicks=(window.clicks||0)+1">Next</button>'
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path=os.environ.get('CHROMIUM_PATH','/usr/local/bin/chromium'),headless=True,args=['--no-sandbox'])
 context=browser.new_context()
 context.route('**/*',lambda route:route.fulfill(status=200,content_type='text/html',body='<html><body></body></html>'))
 page=context.new_page();page.goto('https://signup.live.com/mock')
 def setup(html):
  page.evaluate('sessionStorage.clear();delete window.__rlSignupReady;window.clicks=0')
  page.set_content(html)
  return dict(base,runId=str(uuid.uuid4()))
 def tick(profile,receipts=None):
  return page.evaluate('([profile,receipts])=>('+script+')(profile,receipts)',[profile,receipts or []])
 def ready(): page.evaluate('if(window.__rlSignupReady)window.__rlSignupReady.at=Date.now()-2000')
 for stage,form,checks in [
  ('email','<input type="email" name="email">',{'email':base['email']}),
  ('password','<input type="password" autocomplete="new-password" name="password">',{'password':base['password']}),
  ('name','<input name="FirstName"><input name="LastName">',{'FirstName':'mkrooh','LastName':'rlp'}),
  ('birth','<select id="BirthDay"><option value="">Day</option><option value="12">12</option></select><select id="BirthMonth"><option value="">Month</option><option value="4">April</option></select><input id="BirthYear"><select name="Country"><option value="">Country</option><option value="IQ">Iraq</option></select>',{'#BirthDay':'12','#BirthMonth':'4','#BirthYear':'1999','Country':'IQ'})]:
  profile=setup(form+button)
  assert tick(profile)['status']=='filled-'+stage
  for name,value in checks.items():assert page.locator(name if name.startswith('#') else '[name='+name+']').input_value()==value
  assert page.evaluate('window.clicks')==0
  ready(); r=tick(profile); assert r['status']=='submitted-'+stage,r
  assert page.evaluate('window.clicks')==1
  assert tick(profile)['status']=='awaiting-next-page'
  assert page.evaluate('window.clicks')==1
  # A full reload must retain stage receipt even if native callback was lost.
  page.reload();page.set_content(form+button)
  assert tick(profile)['status']=='awaiting-next-page'
  assert page.evaluate('window.clicks||0')==0
  print('PASS automatic '+stage+' transition, reactive delay and no resend after reload')
 for state,form in [
  ('verification','<p>Enter the code</p><input name="code"><input type="email" name="email">'),
  ('captcha','<p>Prove you are human</p><input type="email" name="email">'),
  ('review-error','<div role="alert">Try again later</div><input type="email" name="email">'),
  ('review-fields','<input type="email" name="email"><input name="phone">'),
  ('review-fields','<input type="email" name="email"><input type="checkbox" required>'),
  ('manual-step','<p>Terms to accept</p><button>Accept</button>')]:
  profile=setup(form+button)
  assert tick(profile)['status']==state,(state,tick(profile))
  ready();tick(profile);assert page.evaluate('window.clicks')==0
  if page.locator('[name=code]').count(): assert page.locator('[name=code]').input_value()==''
  print('PASS stop on '+state)
 profile=setup('<input type="email" name="email" value="changed@example.test">'+button)
 assert tick(profile)['status']=='review-fields'
 assert page.locator('[name=email]').input_value()=='changed@example.test'
 print('PASS preserve manual edits')
 profile=setup('<input type="email" name="email"><button>Next</button><button>Next</button>')
 assert tick(profile)['status']=='manual-step'
 print('PASS ambiguous action stops')
 profile=setup('<input type="email" name="email">'+button)
 page.evaluate('() => { Storage.prototype.setItem=function(){throw Error("blocked")}; }')
 tick(profile);ready();assert tick(profile)['status']=='storage-error'
 assert page.evaluate('window.clicks')==0
 print('PASS receipt storage failure prevents submission')
 for url in ('https://signup.live.com.evil.example/mock','http://signup.live.com/mock','https://login.live.com/mock'):
  page.goto(url);page.set_content('<input type="email" name="email">'+button)
  assert tick(dict(base,runId=str(uuid.uuid4())))['status']=='blocked-origin'
  assert page.locator('[name=email]').input_value()==''
 print('PASS origin isolation')
 context.close()
 live=browser.new_context();page=live.new_page()
 page.goto('https://signup.live.com/signup',wait_until='domcontentloaded',timeout=45000)
 field=page.locator('input[name="email"][type="email"]');field.wait_for(timeout=20000)
 # Exactly ONE invocation. The helper must not click until a later tick.
 output=page.evaluate('([profile])=>('+script+')(profile,[])',[dict(base,runId=str(uuid.uuid4()))])
 assert output['status']=='filled-email',output
 assert field.input_value()==base['email']
 assert output['submitted']==[]
 print('PASS live Microsoft email recognition and fill only; no form submission')
 browser.close()
