"""SOCKS5 UDP integration test. Requires Python 3 and JDK 17 on PATH."""
from pathlib import Path
import shutil, socket, struct, subprocess, tempfile, threading

ROOT = Path(__file__).resolve().parents[1]
JAVA_TEST = r'''
import com.retrivedmods.wclient.network.Socks5UdpTunnel;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.io.IOException;
public class Socks5Integration {
 public static void main(String[] args) throws Exception {
  try (Socks5UdpTunnel tunnel = new Socks5UdpTunnel()) {
   int port = Integer.parseInt(args[0]);
   if (args[1].equals("reject")) {
    try { tunnel.start("127.0.0.1", port, "test-user", "test-pass", "game.example.test", 19132); }
    catch (IOException expected) { System.out.println("PASS rejected authentication; no direct fallback"); return; }
    throw new AssertionError("Authentication rejection was ignored");
   }
   InetSocketAddress endpoint = tunnel.start("127.0.0.1", port, "test-user", "test-pass", "game.example.test", 19132);
   try (DatagramSocket game = new DatagramSocket()) {
    game.setSoTimeout(3000);
    for (String text : new String[]{"raknet-packet-one", "packet-two"}) {
     byte[] payload = text.getBytes(StandardCharsets.UTF_8);
     game.send(new DatagramPacket(payload, payload.length, endpoint));
     DatagramPacket reply = new DatagramPacket(new byte[256], 256); game.receive(reply);
     String actual = new String(reply.getData(), reply.getOffset(), reply.getLength(), StandardCharsets.UTF_8);
     if (!actual.equals("echo:" + text)) throw new AssertionError(actual);
    }
   }
   System.out.println("PASS authenticated UDP round trips, framing and fragmented-response rejection");
  }
 }
}
'''

def read_exact(connection, size):
    value = b''
    while len(value) < size:
        chunk = connection.recv(size-len(value))
        if not chunk: raise AssertionError('Unexpected EOF')
        value += chunk
    return value

def run_case(classes, mode):
    tcp = socket.socket(); tcp.bind(('127.0.0.1', 0)); tcp.listen()
    port = tcp.getsockname()[1]
    done = threading.Event(); errors = []
    def serve():
        try:
            with tcp:
                connection, _ = tcp.accept()
                with connection:
                    connection.settimeout(5)
                    assert read_exact(connection, 3) == b'\x05\x01\x02'
                    if mode == 'reject': connection.sendall(b'\x05\xff'); return
                    connection.sendall(b'\x05\x02')
                    assert read_exact(connection, 1) == b'\x01'
                    username = read_exact(connection, read_exact(connection, 1)[0])
                    password = read_exact(connection, read_exact(connection, 1)[0])
                    assert username == b'test-user' and password == b'test-pass'
                    connection.sendall(b'\x01\x00')
                    assert read_exact(connection, 10) == b'\x05\x03\x00\x01' + bytes(6)
                    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as udp:
                        udp.bind(('127.0.0.1', 0)); udp.settimeout(5)
                        connection.sendall(b'\x05\x00\x00\x01' + bytes(4) + struct.pack('!H', udp.getsockname()[1]))
                        for _ in range(2):
                            packet, peer = udp.recvfrom(65507)
                            assert packet[:4] == b'\x00\x00\x00\x03'
                            length = packet[4]
                            assert packet[5:5+length] == b'game.example.test'
                            assert struct.unpack('!H', packet[5+length:7+length])[0] == 19132
                            body = packet[7+length:]
                            address = b'\x01\x7f\x00\x00\x01\x4a\xbc'
                            udp.sendto(b'\x00\x00\x01' + address + b'BAD-FRAGMENT', peer)
                            udp.sendto(b'\x00\x00\x00' + address + b'echo:' + body, peer)
                        done.wait(5)
        except Exception as error: errors.append(error)
    worker = threading.Thread(target=serve, daemon=True); worker.start()
    try:
        result = subprocess.run([shutil.which('java'), '-cp', str(classes), 'Socks5Integration', str(port), mode],
                                text=True, capture_output=True, timeout=12)
        print(result.stdout.strip())
        if result.returncode: raise AssertionError(result.stderr)
    finally:
        done.set(); worker.join(timeout=2)
    if errors: raise errors[0]

with tempfile.TemporaryDirectory(prefix='rlclient-proxy-test-') as directory:
    root = Path(directory)
    runner = root/'Socks5Integration.java'; runner.write_text(JAVA_TEST)
    source = ROOT/'app/src/main/java/com/retrivedmods/wclient/network/Socks5UdpTunnel.java'
    subprocess.run([shutil.which('javac'), '-d', str(root), str(source), str(runner)], check=True)
    run_case(root, 'auth'); run_case(root, 'reject')
