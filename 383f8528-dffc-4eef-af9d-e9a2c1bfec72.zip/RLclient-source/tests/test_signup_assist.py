"""Exercise the helper without submitting any forms or creating an account.
Requires Playwright and a local Chromium executable.
"""
from pathlib import Path
import json, os
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
script=(ROOT/'app/src/main/assets/signup-assist.js').read_text()
profile={'email':'rlclient-ui-test@example.test','firstName':'Test','lastName':'Example'}
html='''<form onsubmit="window.submitted=true;return false">
<input type="email" name="email"><input name="FirstName"><input name="LastName">
<input type="password" name="password"><input autocomplete="one-time-code" name="code">
<input type="text" name="captcha"><input name="birthDate"><button onclick="window.clicked=true">Next</button></form>'''
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path=os.environ.get('CHROMIUM_PATH','/usr/local/bin/chromium'),headless=True,args=['--no-sandbox'])
 context=browser.new_context()
 # Local-only fixtures with controlled origins.
 context.route('**/*',lambda route:route.fulfill(status=200,content_type='text/html',body=html))
 page=context.new_page();page.goto('https://signup.live.com/mock')
 assert page.evaluate('('+script+')',profile)=='filled'
 assert page.locator('[name=email]').input_value()==profile['email']
 assert page.locator('[name=FirstName]').input_value()=='Test'
 assert page.locator('[name=LastName]').input_value()=='Example'
 for field in ('password','code','captcha','birthDate'):assert page.locator('[name='+field+']').input_value()==''
 assert page.evaluate('!window.clicked && !window.submitted')
 # User edits are never overwritten.
 page.locator('[name=email]').fill('user-choice@example.test')
 page.evaluate('('+script+')',profile)
 assert page.locator('[name=email]').input_value()=='user-choice@example.test'
 print('PASS supported fields, manual edits, no submission, no password/code/CAPTCHA/date mutation')
 for origin in ('https://signup.live.com.evil.example','http://signup.live.com','https://login.live.com'):
  page.goto(origin+'/mock')
  assert page.evaluate('('+script+')',profile)=='blocked-origin'
  assert page.locator('[name=email]').input_value()==''
 print('PASS origin and HTTPS restrictions')
 # React-style delayed form mounting.
 page.goto('https://signup.live.com/mock')
 page.evaluate('document.body.innerHTML=""')
 assert page.evaluate('('+script+')',profile)=='waiting-for-fields'
 page.evaluate('document.body.innerHTML=\'<input type="email" name="email">\'')
 page.wait_for_function('document.querySelector("input").value === "rlclient-ui-test@example.test"')
 print('PASS delayed fields')
 context.close()
 # Real Microsoft page: fill an unroutable example address only. Never click Next.
 live=browser.new_context();page=live.new_page()
 page.goto('https://signup.live.com/signup',wait_until='domcontentloaded',timeout=45000)
 page.locator('input[name="email"][type="email"]').wait_for(timeout=20000)
 assert page.evaluate('('+script+')',profile)=='filled'
 assert page.locator('input[name="email"]').input_value()==profile['email']
 print('PASS live Microsoft initial email field populated; no Next click or form submission')
 browser.close()
